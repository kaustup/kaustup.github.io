// Navigation functionality
document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');

    // Toggle mobile menu
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close mobile menu when clicking on a link
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // Smooth scrolling for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const offsetTop = targetSection.offsetTop - 70;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Active navigation link on scroll
    window.addEventListener('scroll', function() {
        const sections = document.querySelectorAll('section[id]');
        const scrollPos = window.scrollY + 100;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');
            const navLink = document.querySelector(`a[href="#${sectionId}"]`);

            if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
                navLinks.forEach(link => link.classList.remove('active'));
                if (navLink) navLink.classList.add('active');
            }
        });

        // Navbar background on scroll
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 50) {
            navbar.style.background = 'rgba(255, 255, 255, 0.98)';
        } else {
            navbar.style.background = 'rgba(255, 255, 255, 0.95)';
        }
    });

    // Portfolio filter functionality
    const filterButtons = document.querySelectorAll('.filter-btn');
    const portfolioItems = document.querySelectorAll('.portfolio-item');

    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');

            const filterValue = this.getAttribute('data-filter');

            portfolioItems.forEach(item => {
                if (filterValue === 'all') {
                    item.style.display = 'block';
                    item.style.animation = 'fadeIn 0.5s ease';
                } else {
                    const category = item.getAttribute('data-category');
                    if (category === filterValue) {
                        item.style.display = 'block';
                        item.style.animation = 'fadeIn 0.5s ease';
                    } else {
                        item.style.display = 'none';
                    }
                }
            });
        });
    });

    // Form submission
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show success message
            showNotification('Message sent successfully! I\'ll get back to you soon.', 'success');
            
            // Reset form
            this.reset();
        });
    }

    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe elements for animation
    const animateElements = document.querySelectorAll('.service-card, .portfolio-item, .stat-item, .contact-item');
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s ease';
        observer.observe(el);
    });
});

// Popup functionality
function openPopup(popupId) {
    const popup = document.getElementById(popupId);
    if (popup) {
        popup.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Add click outside to close
        popup.addEventListener('click', function(e) {
            if (e.target === popup) {
                closePopup(popupId);
            }
        });
    }
}

function closePopup(popupId) {
    const popup = document.getElementById(popupId);
    if (popup) {
        popup.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
}

// Close popup with Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const activePopup = document.querySelector('.popup-overlay.active');
        if (activePopup) {
            activePopup.classList.remove('active');
            document.body.style.overflow = 'auto';
        }
    }
});

// Notification system
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());

    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">
                ${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}
            </span>
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;

    // Add notification styles if not already added
    if (!document.querySelector('#notification-styles')) {
        const styles = document.createElement('style');
        styles.id = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 3000;
                background: white;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                overflow: hidden;
                animation: slideInNotification 0.3s ease;
            }
            
            .notification-success {
                border-left: 4px solid #10B981;
            }
            
            .notification-error {
                border-left: 4px solid #EF4444;
            }
            
            .notification-info {
                border-left: 4px solid #3B82F6;
            }
            
            .notification-content {
                display: flex;
                align-items: center;
                padding: 16px;
                gap: 12px;
            }
            
            .notification-icon {
                width: 20px;
                height: 20px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: bold;
                font-size: 14px;
                color: white;
            }
            
            .notification-success .notification-icon {
                background: #10B981;
            }
            
            .notification-error .notification-icon {
                background: #EF4444;
            }
            
            .notification-info .notification-icon {
                background: #3B82F6;
            }
            
            .notification-message {
                flex: 1;
                font-size: 14px;
                color: #374151;
            }
            
            .notification-close {
                background: none;
                border: none;
                font-size: 18px;
                cursor: pointer;
                color: #6B7280;
                padding: 0;
                width: 20px;
                height: 20px;
            }
            
            .notification-close:hover {
                color: #374151;
            }
            
            @keyframes slideInNotification {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(styles);
    }

    document.body.appendChild(notification);

    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'slideOutNotification 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Create additional service popups dynamically
function createServicePopups() {
    const servicePopups = [
        {
            id: 'mobile-dev-popup',
            title: 'Mobile Development',
            content: `
                <p>I build robust, scalable server-side applications and APIs that power modern web and mobile applications.</p>
                <div class="service-details">
                    <h4>What I offer:</h4>
                    <ul>
                        <li>RESTful API development</li>
                        <li>Database design and optimization</li>
                        <li>Authentication and authorization</li>
                        <li>Cloud deployment and scaling</li>
                        <li>Microservices architecture</li>
                    </ul>
                    <h4>Technologies used:</h4>
                    <div class="tech-stack">
                        <span>Node.js</span>
                        <span>Python</span>
                        <span>Express</span>
                        <span>Django</span>
                        <span>MongoDB</span>
                        <span>PostgreSQL</span>
                    </div>
                </div>
            `
        }
    ];

    servicePopups.forEach(popup => {
        if (!document.getElementById(popup.id)) {
            const popupHTML = `
                <div id="${popup.id}" class="popup-overlay">
                    <div class="popup-content">
                        <div class="popup-header">
                            <h3>${popup.title}</h3>
                            <button class="close-popup" onclick="closePopup('${popup.id}')">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="popup-body">
                            ${popup.content}
                        </div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', popupHTML);
        }
    });
}

// Create project popups dynamically
function createProjectPopups() {
    const projectPopups = [
        {
            id: 'project2-popup',
            title: 'Task Management App',
            content: `
                <div class="project-details">
                    <div class="project-image-large">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <div class="project-info">
                        <p>A comprehensive task management mobile application built with React Native, featuring real-time synchronization and offline support.</p>
                        <div class="project-features">
                            <h4>Key Features:</h4>
                            <ul>
                                <li>Create, edit, and delete tasks</li>
                                <li>Category and priority management</li>
                                <li>Real-time synchronization across devices</li>
                                <li>Offline mode support</li>
                                <li>Push notifications for reminders</li>
                                <li>Team collaboration features</li>
                            </ul>
                        </div>
                        <div class="project-links">
                            <a href="#" class="btn btn-primary">View Demo</a>
                            <a href="#" class="btn btn-secondary">GitHub</a>
                        </div>
                    </div>
                </div>
            `
        },
        {
            id: 'project3-popup',
            title: 'Brand Identity Design',
            content: `
                <div class="project-details">
                    <div class="project-image-large">
                        <i class="fas fa-paint-brush"></i>
                    </div>
                    <div class="project-info">
                        <p>Complete brand identity design for a technology startup, including logo design, color palette, typography, and brand guidelines.</p>
                        <div class="project-features">
                            <h4>Deliverables:</h4>
                            <ul>
                                <li>Logo design and variations</li>
                                <li>Brand color palette</li>
                                <li>Typography system</li>
                                <li>Business card design</li>
                                <li>Brand guidelines document</li>
                                <li>Social media templates</li>
                            </ul>
                        </div>
                        <div class="project-links">
                            <a href="#" class="btn btn-primary">View Portfolio</a>
                            <a href="#" class="btn btn-secondary">Behance</a>
                        </div>
                    </div>
                </div>
            `
        }
    ];

    projectPopups.forEach(popup => {
        if (!document.getElementById(popup.id)) {
            const popupHTML = `
                <div id="${popup.id}" class="popup-overlay">
                    <div class="popup-content large">
                        <div class="popup-header">
                            <h3>${popup.title}</h3>
                            <button class="close-popup" onclick="closePopup('${popup.id}')">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="popup-body">
                            ${popup.content}
                        </div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', popupHTML);
        }
    });
}

// Typing effect for hero section
function typeWriter(element, text, speed = 100) {
    let i = 0;
    element.innerHTML = '';
    
    function type() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    
    type();
}
// About Page JavaScript with Advanced Animations
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all animations and interactions
    initNavigationAnimations();
    initHeroAnimations();
    initSkillBarAnimations();
    initTimelineAnimations();
    initScrollRevealAnimations();
    initParticleBackground();
    initTypingEffect();
    initCounterAnimations();
    initInteractiveElements();
    addCustomStyles();
});

// Navigation animations
function initNavigationAnimations() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');

    // Mobile menu toggle with animation
    hamburger?.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
        
        // Animate menu items
        if (navMenu.classList.contains('active')) {
            navLinks.forEach((link, index) => {
                link.style.animation = `slideInLeft 0.5s ease ${index * 0.1}s forwards`;
            });
        }
    });

    // Smooth scroll with easing
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                const targetSection = document.querySelector(targetId);
                
                if (targetSection) {
                    smoothScrollTo(targetSection.offsetTop - 70, 800);
                }
            }
            
            // Close mobile menu
            hamburger?.classList.remove('active');
            navMenu?.classList.remove('active');
        });
    });

    // Navbar scroll effect
    let lastScrollY = window.scrollY;
    window.addEventListener('scroll', () => {
        const navbar = document.querySelector('.navbar');
        const currentScrollY = window.scrollY;
        
        if (currentScrollY > lastScrollY && currentScrollY > 100) {
            // Scrolling down
            navbar.style.transform = 'translateY(-100%)';
        } else {
            // Scrolling up
            navbar.style.transform = 'translateY(0)';
        }
        
        // Change navbar background on scroll
        if (currentScrollY > 50) {
            navbar.style.background = 'rgba(255, 255, 255, 0.98)';
            navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
        } else {
            navbar.style.background = 'rgba(255, 255, 255, 0.95)';
            navbar.style.boxShadow = 'none';
        }
        
        lastScrollY = currentScrollY;
    });
}

// Hero section animations
function initHeroAnimations() {
    const heroTitle = document.querySelector('.about-hero-title');
    const heroDescription = document.querySelector('.about-hero-description');
    const breadcrumb = document.querySelector('.breadcrumb');

    // Animated text reveal
    if (heroTitle) {
        const text = heroTitle.textContent;
        heroTitle.innerHTML = '';
        
        // Split text into spans
        text.split('').forEach((char, index) => {
            const span = document.createElement('span');
            span.textContent = char === ' ' ? '\u00A0' : char;
            span.style.opacity = '0';
            span.style.transform = 'translateY(50px) rotateX(90deg)';
            span.style.display = 'inline-block';
            span.style.animation = `letterDrop 0.6s ease ${index * 0.05}s forwards`;
            heroTitle.appendChild(span);
        });
    }

    // Breadcrumb animation
    if (breadcrumb) {
        breadcrumb.style.opacity = '0';
        breadcrumb.style.transform = 'translateX(-30px)';
        setTimeout(() => {
            breadcrumb.style.transition = 'all 0.8s ease';
            breadcrumb.style.opacity = '1';
            breadcrumb.style.transform = 'translateX(0)';
        }, 300);
    }

    // Description fade in
    if (heroDescription) {
        heroDescription.style.opacity = '0';
        heroDescription.style.transform = 'translateY(30px)';
        setTimeout(() => {
            heroDescription.style.transition = 'all 1s ease';
            heroDescription.style.opacity = '1';
            heroDescription.style.transform = 'translateY(0)';
        }, 800);
    }
}

// Skill bars animation
function initSkillBarAnimations() {
    const skillBars = document.querySelectorAll('.skill-progress');
    
    const skillObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const skillBar = entry.target;
                const width = skillBar.getAttribute('data-width');
                
                // Animate skill bar fill
                setTimeout(() => {
                    skillBar.style.width = width + '%';
                    skillBar.style.transition = 'width 1.5s cubic-bezier(0.4, 0, 0.2, 1)';
                    
                    // Add glow effect
                    skillBar.style.boxShadow = `0 0 10px var(--primary-color)`;
                    
                    // Animate percentage counter
                    animatePercentage(skillBar.parentElement.querySelector('.skill-level'), width);
                }, 200);
                
                skillObserver.unobserve(skillBar);
            }
        });
    }, { threshold: 0.5 });

    skillBars.forEach(bar => skillObserver.observe(bar));
}

// Timeline animations
function initTimelineAnimations() {
    const timelineItems = document.querySelectorAll('.timeline-item');
    
    const timelineObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                const item = entry.target;
                const marker = item.querySelector('.timeline-marker');
                const content = item.querySelector('.timeline-content');
                
                // Animate marker
                setTimeout(() => {
                    marker.style.transform = 'scale(1.2)';
                    marker.style.background = 'var(--gradient-primary)';
                    
                    setTimeout(() => {
                        marker.style.transform = 'scale(1)';
                    }, 300);
                }, index * 200);
                
                // Animate content
                setTimeout(() => {
                    content.style.opacity = '1';
                    content.style.transform = 'translateX(0) translateY(0)';
                }, index * 200 + 100);
                
                // Animate tags
                const tags = item.querySelectorAll('.timeline-tags span');
                tags.forEach((tag, tagIndex) => {
                    setTimeout(() => {
                        tag.style.opacity = '1';
                        tag.style.transform = 'translateY(0) scale(1)';
                    }, index * 200 + 400 + tagIndex * 100);
                });
                
                timelineObserver.unobserve(item);
            }
        });
    }, { threshold: 0.3 });

    timelineItems.forEach(item => {
        const content = item.querySelector('.timeline-content');
        const tags = item.querySelectorAll('.timeline-tags span');
        
        // Set initial states
        content.style.opacity = '0';
        content.style.transform = 'translateX(-50px) translateY(20px)';
        content.style.transition = 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
        
        tags.forEach(tag => {
            tag.style.opacity = '0';
            tag.style.transform = 'translateY(20px) scale(0.8)';
            tag.style.transition = 'all 0.5s ease';
        });
        
        timelineObserver.observe(item);
    });
}

// Scroll reveal animations
function initScrollRevealAnimations() {
    const revealElements = document.querySelectorAll('.value-card, .fact-item, .story-text, .story-image');
    
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                const element = entry.target;
                
                setTimeout(() => {
                    element.classList.add('revealed');
                    
                    // Add special effects for different elements
                    if (element.classList.contains('value-card')) {
                        addValueCardEffect(element);
                    } else if (element.classList.contains('story-image')) {
                        addImageRevealEffect(element);
                    }
                }, index * 150);
                
                revealObserver.unobserve(element);
            }
        });
    }, { threshold: 0.2 });

    revealElements.forEach((element, index) => {
        // Set initial state
        element.style.opacity = '0';
        element.style.transform = 'translateY(50px)';
        element.style.transition = 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
        
        revealObserver.observe(element);
    });
}

// Particle background effect
function initParticleBackground() {
    const canvas = document.createElement('canvas');
    canvas.id = 'particleCanvas';
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.zIndex = '-1';
    canvas.style.pointerEvents = 'none';
    document.body.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    let particles = [];
    let mouse = { x: 0, y: 0 };

    // Resize canvas
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    // Particle class
    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.vx = (Math.random() - 0.5) * 2;
            this.vy = (Math.random() - 0.5) * 2;
            this.radius = Math.random() * 3 + 1;
            this.opacity = Math.random() * 0.5 + 0.2;
        }

        update() {
            this.x += this.vx;
            this.y += this.vy;

            // Bounce off edges
            if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
            if (this.y < 0 || this.y > canvas.height) this.vy *= -1;

            // Mouse interaction
            const dx = mouse.x - this.x;
            const dy = mouse.y - this.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < 100) {
                const force = (100 - distance) / 100;
                this.vx -= (dx / distance) * force * 0.5;
                this.vy -= (dy / distance) * force * 0.5;
            }
        }

        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(102, 126, 234, ${this.opacity})`;
            ctx.fill();
        }
    }

    // Initialize particles
    function initParticles() {
        particles = [];
        const particleCount = Math.floor((canvas.width * canvas.height) / 15000);
        
        for (let i = 0; i < particleCount; i++) {
            particles.push(new Particle());
        }
    }

    // Animation loop
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        particles.forEach(particle => {
            particle.update();
            particle.draw();
        });

        // Draw connections
        particles.forEach((particle, i) => {
            particles.slice(i + 1).forEach(otherParticle => {
                const dx = particle.x - otherParticle.x;
                const dy = particle.y - otherParticle.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < 120) {
                    ctx.beginPath();
                    ctx.moveTo(particle.x, particle.y);
                    ctx.lineTo(otherParticle.x, otherParticle.y);
                    ctx.strokeStyle = `rgba(102, 126, 234, ${0.2 * (1 - distance / 120)})`;
                    ctx.lineWidth = 1;
                    ctx.stroke();
                }
            });
        });

        requestAnimationFrame(animate);
    }

    // Event listeners
    window.addEventListener('resize', () => {
        resizeCanvas();
        initParticles();
    });

    document.addEventListener('mousemove', (e) => {
        mouse.x = e.clientX;
        mouse.y = e.clientY;
    });

    // Initialize
    resizeCanvas();
    initParticles();
    animate();
}

// Typing effect for story section
function initTypingEffect() {
    const storyParagraphs = document.querySelectorAll('.story-paragraphs p');
    
    storyParagraphs.forEach((paragraph, index) => {
        const text = paragraph.textContent;
        paragraph.textContent = '';
        paragraph.style.borderRight = '2px solid var(--primary-color)';
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        typeText(paragraph, text, 30);
                    }, index * 1000);
                    observer.unobserve(paragraph);
                }
            });
        });
        
        observer.observe(paragraph);
    });
}

// Counter animations for stats
function initCounterAnimations() {
    const counters = document.querySelectorAll('[data-count]');
    
    const counterObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = parseInt(counter.getAttribute('data-count'));
                animateCounter(counter, 0, target, 2000);
                counterObserver.unobserve(counter);
            }
        });
    });

    counters.forEach(counter => counterObserver.observe(counter));
}

// Interactive elements
function initInteractiveElements() {
    // Skill category hover effects
    const skillCategories = document.querySelectorAll('.skills-category');
    skillCategories.forEach(category => {
        category.addEventListener('mouseenter', () => {
            category.style.transform = 'translateY(-5px) scale(1.02)';
            category.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.1)';
        });
        
        category.addEventListener('mouseleave', () => {
            category.style.transform = 'translateY(0) scale(1)';
            category.style.boxShadow = 'var(--shadow-light)';
        });
    });

    // Value card interactions
    const valueCards = document.querySelectorAll('.value-card');
    valueCards.forEach((card, index) => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-10px) rotateY(5deg)';
            card.style.boxShadow = '0 25px 50px rgba(0, 0, 0, 0.15)';
            
            // Add ripple effect
            createRippleEffect(card, event);
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0) rotateY(0)';
            card.style.boxShadow = 'var(--shadow-light)';
        });
        
        card.addEventListener('click', () => {
            // Add click animation
            card.style.transform = 'scale(0.95)';
            setTimeout(() => {
                card.style.transform = 'scale(1)';
            }, 150);
        });
    });

    // Timeline item hover effects
    const timelineItems = document.querySelectorAll('.timeline-item');
    timelineItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            const marker = item.querySelector('.timeline-marker');
            marker.style.transform = 'scale(1.3) rotateZ(360deg)';
            marker.style.background = 'linear-gradient(45deg, var(--primary-color), var(--secondary-color))';
        });
        
        item.addEventListener('mouseleave', () => {
            const marker = item.querySelector('.timeline-marker');
            marker.style.transform = 'scale(1) rotateZ(0deg)';
            marker.style.background = 'var(--gradient-primary)';
        });
    });
}

// Utility Functions

// Smooth scroll function
function smoothScrollTo(target, duration) {
    const start = window.pageYOffset;
    const distance = target - start;
    let startTime = null;

    function animation(currentTime) {
        if (startTime === null) startTime = currentTime;
        const timeElapsed = currentTime - startTime;
        const run = ease(timeElapsed, start, distance, duration);
        window.scrollTo(0, run);
        if (timeElapsed < duration) requestAnimationFrame(animation);
    }

    function ease(t, b, c, d) {
        t /= d / 2;
        if (t < 1) return c / 2 * t * t + b;
        t--;
        return -c / 2 * (t * (t - 2) - 1) + b;
    }

    requestAnimationFrame(animation);
}

// Type text effect
function typeText(element, text, speed) {
    let i = 0;
    const timer = setInterval(() => {
        if (i < text.length) {
            element.textContent += text.charAt(i);
            i++;
        } else {
            clearInterval(timer);
            element.style.borderRight = 'none';
        }
    }, speed);
}

// Animate percentage counter
function animatePercentage(element, target) {
    let current = 0;
    const increment = target / 60;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target + '%';
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current) + '%';
        }
    }, 25);
}

// Animate counter
function animateCounter(element, start, end, duration) {
    const range = end - start;
    const startTime = performance.now();
    
    function updateCounter(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const current = start + (range * easeOutQuart(progress));
        
        element.textContent = Math.floor(current);
        
        if (progress < 1) {
            requestAnimationFrame(updateCounter);
        }
    }
    
    requestAnimationFrame(updateCounter);
}

// Easing function
function easeOutQuart(t) {
    return 1 - (--t) * t * t * t;
}

// Add special effects for value cards
function addValueCardEffect(card) {
    const icon = card.querySelector('.value-icon');
    if (icon) {
        icon.style.animation = 'bounceIn 0.8s ease';
        
        setTimeout(() => {
            icon.style.animation = 'pulse 2s infinite';
        }, 800);
    }
}

// Add image reveal effect
function addImageRevealEffect(element) {
    const placeholder = element.querySelector('.profile-placeholder');
    if (placeholder) {
        placeholder.style.animation = 'zoomIn 1s ease';
        
        // Add floating animation
        setTimeout(() => {
            placeholder.style.animation = 'float 3s ease-in-out infinite';
        }, 1000);
    }
}

// Create ripple effect
function createRippleEffect(element, event) {
    const ripple = document.createElement('span');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event ? event.clientX - rect.left - size / 2 : rect.width / 2 - size / 2;
    const y = event ? event.clientY - rect.top - size / 2 : rect.height / 2 - size / 2;
    
    ripple.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        left: ${x}px;
        top: ${y}px;
        background: radial-gradient(circle, rgba(102, 126, 234, 0.3) 0%, transparent 70%);
        border-radius: 50%;
        transform: scale(0);
        animation: ripple 0.6s ease-out;
        pointer-events: none;
        z-index: 1;
    `;
    
    element.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// Add custom styles for animations
function addCustomStyles() {
    if (document.getElementById('about-animations')) return;
    
    const styles = document.createElement('style');
    styles.id = 'about-animations';
    styles.textContent = `
        /* Animation Keyframes */
        @keyframes letterDrop {
            0% {
                opacity: 0;
                transform: translateY(50px) rotateX(90deg);
            }
            50% {
                opacity: 1;
                transform: translateY(-10px) rotateX(0deg);
            }
            100% {
                opacity: 1;
                transform: translateY(0) rotateX(0deg);
            }
        }
        
        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-100px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes bounceIn {
            0% {
                opacity: 0;
                transform: scale(0.3) translateY(30px);
            }
            50% {
                opacity: 1;
                transform: scale(1.1) translateY(-10px);
            }
            70% {
                transform: scale(0.9) translateY(5px);
            }
            100% {
                opacity: 1;
                transform: scale(1) translateY(0);
            }
        }
        
        @keyframes zoomIn {
            from {
                opacity: 0;
                transform: scale(0.5);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
        
        @keyframes float {
            0%, 100% {
                transform: translateY(0px);
            }
            50% {
                transform: translateY(-20px);
            }
        }
        
        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.1);
            }
        }
        
        @keyframes ripple {
            to {
                transform: scale(2);
                opacity: 0;
            }
        }
        
        /* Enhanced Styles */
        .navbar {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .revealed {
            opacity: 1 !important;
            transform: translateY(0) !important;
        }
        
        .skill-progress {
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
            border-radius: 10px;
            position: relative;
            overflow: hidden;
        }
        
        .skill-progress::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: shimmer 2s infinite;
        }
        
        @keyframes shimmer {
            0% { left: -100%; }
            100% { left: 100%; }
        }
        
        .timeline-marker {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .value-card {
            position: relative;
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .skills-category {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        /* Responsive animations */
        @media (prefers-reduced-motion: reduce) {
            * {
                animation-duration: 0.01ms !important;
                animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important;
            }
        }
        
        @media (max-width: 768px) {
            .timeline-content {
                transform: translateY(20px) !important;
            }
            
            .value-card:hover {
                transform: translateY(-5px) !important;
            }
        }
    `;
    
    document.head.appendChild(styles);
}

// Initialize page load animations
window.addEventListener('load', () => {
    document.body.classList.add('page-loaded');
    
    // Trigger initial animations
    setTimeout(() => {
        const heroSection = document.querySelector('.about-hero');
        if (heroSection) {
            heroSection.style.opacity = '1';
            heroSection.style.transform = 'translateY(0)';
        }
    }, 100);
});

// Add page transition effects
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
        // Restart subtle animations when page becomes visible
        const animatedElements = document.querySelectorAll('.profile-placeholder, .value-icon');
        animatedElements.forEach(el => {
            el.style.animationPlayState = 'running';
        });
    } else {
        // Pause animations when page is hidden
        const animatedElements = document.querySelectorAll('.profile-placeholder, .value-icon');
        animatedElements.forEach(el => {
            el.style.animationPlayState = 'paused';
        });
    }
});