// Enhanced About Page JavaScript - Fixed Loading Screen
class EnhancedAboutPage {
    constructor() {
        this.init();
    }

    init() {
        this.initEmailJS();
        this.initLoadingScreen();
        this.initNavbar();
        this.initThemeToggle();
        this.initParticles();
        this.initAnimations();
        this.initSkillBars();
        this.initContactForm();
        this.initStatCounters();
        this.initScrollEffects();
        this.initMobileMenu();
        this.initTypewriter();
        this.initParallax();
        this.initPerformanceOptimizations();
        this.initEasterEggs();
    }

    // Initialize EmailJS
    initEmailJS() {
        if (typeof emailjs !== 'undefined') {
            emailjs.init('7-nn79nY1XGH5qq_H');
            console.log('EmailJS initialized successfully');
        } else {
            console.warn('EmailJS not loaded');
        }
    }

    // Fixed Loading Screen
    initLoadingScreen() {
        const loadingScreen = document.getElementById('loadingScreen');
        
        if (!loadingScreen) {
            console.warn('Loading screen element not found');
            this.startPageAnimations();
            return;
        }

        // Ensure the loading screen is visible initially
        loadingScreen.style.opacity = '1';
        loadingScreen.style.visibility = 'visible';

        window.addEventListener('load', () => {
            // Add a minimum loading time to prevent flash
            const minLoadTime = 1500; // 1.5 seconds minimum
            const startTime = Date.now();
            
            const hideLoadingScreen = () => {
                const elapsed = Date.now() - startTime;
                const remainingTime = Math.max(0, minLoadTime - elapsed);
                
                setTimeout(() => {
                    loadingScreen.classList.add('hide');
                    
                    // Remove the loading screen after transition
                    setTimeout(() => {
                        loadingScreen.style.display = 'none';
                        this.startPageAnimations();
                    }, 800); // Wait for transition to complete
                }, remainingTime);
            };

            hideLoadingScreen();
        });

        // Fallback: Hide loading screen after maximum time
        setTimeout(() => {
            if (loadingScreen && !loadingScreen.classList.contains('hide')) {
                loadingScreen.classList.add('hide');
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                    this.startPageAnimations();
                }, 800);
            }
        }, 5000); // 5 second maximum
    }

    // Start page animations after loading
    startPageAnimations() {
        // Animate hero elements
        const heroElements = document.querySelectorAll('.hero-text > *');
        heroElements.forEach((element, index) => {
            if (element) {
                element.style.opacity = '0';
                element.style.transform = 'translateY(30px)';
                element.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
                
                setTimeout(() => {
                    element.style.opacity = '1';
                    element.style.transform = 'translateY(0)';
                }, index * 200 + 100);
            }
        });

        // Animate profile card
        const profileCard = document.querySelector('.profile-card');
        if (profileCard) {
            profileCard.style.opacity = '0';
            profileCard.style.transform = 'scale(0.8)';
            profileCard.style.transition = 'opacity 1s ease, transform 1s ease';
            
            setTimeout(() => {
                profileCard.style.opacity = '1';
                profileCard.style.transform = 'scale(1)';
            }, 500);
        }
    }

    // Enhanced Navbar with scroll effects
    initNavbar() {
        const navbar = document.getElementById('navbar');
        if (!navbar) return;

        let lastScrollY = window.scrollY;

        const handleScroll = () => {
            const currentScrollY = window.scrollY;
            
            // Add/remove scrolled class
            if (currentScrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }

            // Hide/show navbar on scroll
            if (currentScrollY > lastScrollY && currentScrollY > 100) {
                navbar.style.transform = 'translateY(-100%)';
            } else {
                navbar.style.transform = 'translateY(0)';
            }

            lastScrollY = currentScrollY;
        };

        window.addEventListener('scroll', handleScroll, { passive: true });

        // Active link highlighting
        this.updateActiveNavLink();
        window.addEventListener('scroll', () => this.updateActiveNavLink(), { passive: true });
    }

    updateActiveNavLink() {
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-link');
        
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.offsetHeight;
            
            if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            const href = link.getAttribute('href');
            if (href && href.includes(current) && current !== '') {
                link.classList.add('active');
            }
        });
    }

    // Enhanced Theme Toggle with smooth transitions
    initThemeToggle() {
        const themeToggle = document.getElementById('themeToggle');
        const body = document.body;
        
        if (!themeToggle) return;
        
        // Load saved theme
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            body.classList.add('dark-mode');
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        }

        themeToggle.addEventListener('click', () => {
            // Add transition effect
            body.style.transition = 'background-color 0.6s ease, color 0.6s ease';
            
            body.classList.toggle('dark-mode');
            const isDark = body.classList.contains('dark-mode');
            
            // Icon animation
            themeToggle.style.transform = 'rotate(360deg)';
            themeToggle.style.transition = 'transform 0.3s ease';
            
            setTimeout(() => {
                themeToggle.innerHTML = isDark ? 
                    '<i class="fas fa-sun"></i>' : 
                    '<i class="fas fa-moon"></i>';
                themeToggle.style.transform = 'rotate(0deg)';
            }, 300);
            
            // Save theme preference
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            
            // Create ripple effect
            this.createRippleEffect(themeToggle);
        });
    }

    // Create ripple effect for buttons
    createRippleEffect(element) {
        const ripple = document.createElement('span');
        const rect = element.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        
        ripple.style.cssText = `
            width: ${size}px;
            height: ${size}px;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            position: absolute;
            background: rgba(255, 255, 255, 0.6);
            border-radius: 50%;
            pointer-events: none;
            animation: ripple 0.6s linear;
        `;
        
        element.style.position = 'relative';
        element.style.overflow = 'hidden';
        element.appendChild(ripple);
        
        setTimeout(() => {
            if (ripple.parentNode) {
                ripple.remove();
            }
        }, 600);
    }

    // Dynamic Particles System
    initParticles() {
        const particlesContainer = document.getElementById('particles');
        if (!particlesContainer) return;

        const particleCount = 30; // Reduced for performance

        for (let i = 0; i < particleCount; i++) {
            setTimeout(() => {
                this.createParticle(particlesContainer);
            }, i * 100);
        }

        // Continuously create new particles
        setInterval(() => {
            if (document.visibilityState === 'visible') {
                this.createParticle(particlesContainer);
            }
        }, 4000);
    }

    createParticle(container) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        
        // Random properties
        const size = Math.random() * 6 + 2;
        const left = Math.random() * 100;
        const animationDuration = Math.random() * 8 + 12;
        const opacity = Math.random() * 0.4 + 0.2;
        
        particle.style.cssText = `
            width: ${size}px;
            height: ${size}px;
            left: ${left}%;
            animation-duration: ${animationDuration}s;
            opacity: ${opacity};
        `;
        
        // Random gradient colors
        const gradients = [
            'linear-gradient(45deg, #667eea, #764ba2)',
            'linear-gradient(45deg, #4facfe, #00f2fe)',
            'linear-gradient(45deg, #ff6b6b, #ff8e8e)',
            'linear-gradient(45deg, #4ecdc4, #44a08d)',
            'linear-gradient(45deg, #a855f7, #e879f9)'
        ];
        
        particle.style.background = gradients[Math.floor(Math.random() * gradients.length)];
        
        container.appendChild(particle);
        
        // Remove particle after animation
        setTimeout(() => {
            if (particle.parentNode) {
                particle.parentNode.removeChild(particle);
            }
        }, animationDuration * 1000);
    }

    // Intersection Observer for animations
    initAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    
                    // Stagger animation for multiple elements
                    if (entry.target.classList.contains('stagger-children')) {
                        const children = entry.target.children;
                        Array.from(children).forEach((child, index) => {
                            setTimeout(() => {
                                child.classList.add('visible');
                            }, index * 200);
                        });
                    }
                    
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        // Observe elements
        const animatedElements = document.querySelectorAll(
            '.story-card, .skill-category, .project-card, .contact-card, ' +
            '.timeline-item, .section-header, .hero-visual'
        );
        
        animatedElements.forEach(element => {
            element.classList.add('fade-in');
            observer.observe(element);
        });
    }

    // Enhanced Skill Bars with stagger animation
    initSkillBars() {
        const skillItems = document.querySelectorAll('.skill-item');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const skillProgress = entry.target.querySelector('.skill-progress');
                    const percentage = entry.target.dataset.skill;
                    
                    if (skillProgress && percentage) {
                        setTimeout(() => {
                            skillProgress.style.width = percentage + '%';
                            
                            // Add glow effect
                            const skillGlow = entry.target.querySelector('.skill-glow');
                            if (skillGlow) {
                                setTimeout(() => {
                                    skillGlow.style.opacity = '0.7';
                                }, 500);
                            }
                            
                            // Animate percentage counter
                            this.animateCounter(
                                entry.target.querySelector('.skill-percentage'), 
                                0, 
                                parseInt(percentage)
                            );
                        }, 200);
                    }
                    
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.3 });

        skillItems.forEach(item => observer.observe(item));
    }

    // Enhanced Contact Form with validation and animations
    initContactForm() {
        const form = document.getElementById('contactForm');
        if (!form) return;

        // Form field animations
        const formGroups = form.querySelectorAll('.form-group');
        formGroups.forEach(group => {
            const input = group.querySelector('input, textarea');
            const label = group.querySelector('label');

            if (input && label) {
                // Focus effects
                input.addEventListener('focus', () => {
                    group.classList.add('focused');
                    this.createInputRipple(input);
                });

                input.addEventListener('blur', () => {
                    if (!input.value.trim()) {
                        group.classList.remove('focused');
                    }
                });

                // Real-time validation
                input.addEventListener('input', () => {
                    this.validateField(input);
                });
            }
        });

        // Form submission
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const submitBtn = form.querySelector('.btn-submit');
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');
            const messageInput = document.getElementById('message');

            if (!nameInput || !emailInput || !messageInput) {
                console.error('Form inputs not found');
                return;
            }

            // Validate all fields
            const isValid = this.validateForm(nameInput, emailInput, messageInput);
            if (!isValid) return;

            // Show loading state
            this.setButtonLoading(submitBtn, true);

            try {
                if (typeof emailjs !== 'undefined') {
                    await emailjs.send('service_zr3dhbr', 'template_xkd14cm', {
                        from_name: nameInput.value,
                        from_email: emailInput.value,
                        message: messageInput.value
                    });

                    // Success animation
                    this.showFormSuccess(submitBtn, form);
                } else {
                    throw new Error('EmailJS not available');
                }
                
            } catch (error) {
                console.error('Email sending failed:', error);
                this.showFormError(submitBtn);
            }
        });
    }

    // Animated counters for statistics
    initStatCounters() {
        const statNumbers = document.querySelectorAll('.stat-number');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const target = parseInt(entry.target.dataset.target);
                    this.animateCounter(entry.target, 0, target, 2000);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        statNumbers.forEach(stat => observer.observe(stat));
    }

    animateCounter(element, start, end, duration = 1000) {
        if (!element) return;
        
        const startTime = performance.now();
        const startValue = start;
        const endValue = end;
        
        const updateCounter = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function for smooth animation
            const easeOutCubic = 1 - Math.pow(1 - progress, 3);
            const current = Math.floor(startValue + (endValue - startValue) * easeOutCubic);
            
            element.textContent = current;
            
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            } else {
                element.textContent = endValue;
            }
        };
        
        requestAnimationFrame(updateCounter);
    }

    // Advanced scroll effects
    initScrollEffects() {
        let ticking = false;
        
        const updateScrollEffects = () => {
            const scrolled = window.pageYOffset;
            const heroSection = document.querySelector('.hero-section');
            const shapes = document.querySelectorAll('.shape');
            
            if (heroSection) {
                const heroSpeed = scrolled * 0.3;
                heroSection.style.transform = `translateY(${heroSpeed}px)`;
            }
            
            // Animate floating shapes
            shapes.forEach((shape, index) => {
                const speed = (index + 1) * 0.1;
                shape.style.transform = `translateY(${scrolled * speed}px) rotate(${scrolled * 0.05}deg)`;
            });
            
            ticking = false;
        };

        // Parallax effect for hero section
        window.addEventListener('scroll', () => {
            if (!ticking) {
                requestAnimationFrame(updateScrollEffects);
                ticking = true;
            }
        }, { passive: true });

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const href = anchor.getAttribute('href');
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    // Mobile menu functionality
    initMobileMenu() {
        const hamburger = document.getElementById('hamburger');
        const navMenu = document.getElementById('navMenu');
        
        if (!hamburger || !navMenu) return;

        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
            document.body.classList.toggle('menu-open');
        });

        // Close menu when clicking on a link
        navMenu.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
                document.body.classList.remove('menu-open');
            });
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navMenu.contains(e.target)) {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
                document.body.classList.remove('menu-open');
            }
        });
    }

    // Typewriter effect for hero title
    initTypewriter() {
        const titleHighlight = document.querySelector('.title-highlight');
        if (!titleHighlight) return;
        
        const text = titleHighlight.textContent;
        titleHighlight.textContent = '';
        
        let index = 0;
        const typeWriter = () => {
            if (index < text.length) {
                titleHighlight.textContent += text.charAt(index);
                index++;
                setTimeout(typeWriter, 150);
            }
        };
        
        setTimeout(typeWriter, 1500);
    }

    // Parallax scrolling effects
    initParallax() {
        const parallaxElements = document.querySelectorAll('.parallax');
        
        let ticking = false;
        
        const updateParallax = () => {
            const scrollTop = window.pageYOffset;
            
            parallaxElements.forEach(element => {
                const speed = element.dataset.speed || 0.5;
                const yPos = -(scrollTop * speed);
                element.style.transform = `translateY(${yPos}px)`;
            });
            
            ticking = false;
        };
        
        window.addEventListener('scroll', () => {
            if (!ticking) {
                requestAnimationFrame(updateParallax);
                ticking = true;
            }
        }, { passive: true });
    }

    // Performance optimizations
    initPerformanceOptimizations() {
        // Lazy loading for images
        const images = document.querySelectorAll('img[data-src]');
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.add('loaded');
                    imageObserver.unobserve(img);
                }
            });
        });

        images.forEach(img => imageObserver.observe(img));
    }

    // Easter eggs and fun interactions
    initEasterEggs() {
        let konami = [];
        const konamiCode = [38, 38, 40, 40, 37, 39, 37, 39, 66, 65];
        
        document.addEventListener('keydown', (e) => {
            konami.push(e.keyCode);
            if (konami.length > konamiCode.length) {
                konami.shift();
            }
            
            if (JSON.stringify(konami) === JSON.stringify(konamiCode)) {
                this.triggerEasterEgg();
                konami = [];
            }
        });
    }

    triggerEasterEgg() {
        document.body.style.animation = 'rainbow 2s ease';
        
        setTimeout(() => {
            document.body.style.animation = 'none';
        }, 2000);
        
        this.showNotification('🎉 Konami Code activated!', 'success');
    }

    // Form validation and helper methods
    validateField(input) {
        const value = input.value.trim();
        let isValid = true;
        let errorMessage = '';

        this.removeFieldError(input);

        switch (input.type) {
            case 'email':
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(value)) {
                    isValid = false;
                    errorMessage = 'Please enter a valid email address';
                }
                break;
            case 'text':
                if (value.length < 2) {
                    isValid = false;
                    errorMessage = 'Name must be at least 2 characters long';
                }
                break;
            default:
                if (input.tagName === 'TEXTAREA' && value.length < 10) {
                    isValid = false;
                    errorMessage = 'Message must be at least 10 characters long';
                }
        }

        if (!isValid) {
            this.showFieldError(input, errorMessage);
        }

        return isValid;
    }

    validateForm(nameInput, emailInput, messageInput) {
        let isValid = true;
        
        if (!this.validateField(nameInput)) isValid = false;
        if (!this.validateField(emailInput)) isValid = false;
        if (!this.validateField(messageInput)) isValid = false;

        return isValid;
    }

    showFieldError(input, message) {
        const formGroup = input.closest('.form-group');
        if (!formGroup) return;

        formGroup.classList.add('error');
        
        let errorElement = formGroup.querySelector('.error-message');
        if (!errorElement) {
            errorElement = document.createElement('div');
            errorElement.className = 'error-message';
            errorElement.style.cssText = 'color: #ff6b6b; font-size: 0.8rem; margin-top: 0.5rem;';
            formGroup.appendChild(errorElement);
        }
        
        errorElement.textContent = message;
    }

    removeFieldError(input) {
        const formGroup = input.closest('.form-group');
        if (!formGroup) return;

        formGroup.classList.remove('error');
        const errorElement = formGroup.querySelector('.error-message');
        if (errorElement) {
            errorElement.remove();
        }
    }

    createInputRipple(input) {
        const formGroup = input.closest('.form-group');
        const inputLine = formGroup.querySelector('.input-line');
        
        if (inputLine) {
            inputLine.style.width = '100%';
        }
    }

    setButtonLoading(button, loading) {
        if (!button) return;
        
        if (loading) {
            button.classList.add('loading');
            button.disabled = true;
        } else {
            button.classList.remove('loading');
            button.disabled = false;
        }
    }

    showFormSuccess(button, form) {
        if (!button || !form) return;
        
        button.classList.remove('loading');
        button.classList.add('success');
        const btnText = button.querySelector('.btn-text');
        if (btnText) {
            btnText.textContent = 'Message Sent!';
        }
        
        setTimeout(() => {
            form.reset();
            button.classList.remove('success');
            if (btnText) {
                btnText.textContent = 'Send Message';
            }
            this.showNotification('Message sent successfully!', 'success');
        }, 2000);
    }

    showFormError(button) {
        if (!button) return;
        
        button.classList.remove('loading');
        button.classList.add('error');
        
        setTimeout(() => {
            button.classList.remove('error');
        }, 3000);
        
        this.showNotification('Failed to send message. Please try again.', 'error');
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        
        const bgColor = type === 'success' ? '#4ecdc4' : type === 'error' ? '#ff6b6b' : '#667eea';
        
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${bgColor};
            color: white;
            padding: 1rem 2rem;
            border-radius: 8px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            z-index: 10000;
            max-width: 300px;
            word-wrap: break-word;
            font-family: 'Inter', sans-serif;
            animation: slideInRight 0.5s ease;
        `;
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.5s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 500);
        }, 4000);
    }
}

// CSS Animations
const dynamicStyles = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    @keyframes ripple {
        0% { transform: translate(-50%, -50%) scale(0); opacity: 1; }
        100% { transform: translate(-50%, -50%) scale(4); opacity: 0; }
    }
    
    @keyframes rainbow {
        0% { filter: hue-rotate(0deg); }
        100% { filter: hue-rotate(360deg); }
    }
    
    .loading-screen {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        opacity: 1;
        visibility: visible;
        transition: opacity 0.8s ease, visibility 0.8s ease;
    }
    
    .loading-screen.hide {
        opacity: 0;
        visibility: hidden;
    }
`;

// Inject styles
const styleSheet = document.createElement('style');
styleSheet.textContent = dynamicStyles;
document.head.appendChild(styleSheet);

// Initialize the enhanced about page
document.addEventListener('DOMContentLoaded', () => {
    new EnhancedAboutPage();
});