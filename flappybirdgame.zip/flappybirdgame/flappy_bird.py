import pygame
import random
import math
import json
import os
from enum import Enum
from dataclasses import dataclass
from typing import List, Tuple
import time

# Initialize Pygame
pygame.init()
pygame.mixer.init()

# Game constants - Ultra HD Experience
WINDOW_WIDTH = 1600
WINDOW_HEIGHT = 1000
FPS = 60

# Enhanced cyberpunk anime color palettes
class Colors:
    # Core cyberpunk palette
    VOID_BLACK = (5, 5, 15)
    DEEP_SPACE = (10, 15, 35)
    NEON_CYAN = (0, 255, 255)
    NEON_PINK = (255, 20, 147)
    NEON_GREEN = (57, 255, 20)
    ELECTRIC_BLUE = (0, 191, 255)
    LASER_PURPLE = (138, 43, 226)
    PLASMA_ORANGE = (255, 165, 0)
    QUANTUM_GOLD = (255, 223, 0)
    MATRIX_GREEN = (0, 255, 65)
    HOLOGRAM_WHITE = (240, 248, 255)
    ENERGY_RED = (255, 69, 0)
    
    # Anime-inspired additions
    SAKURA_PINK = (255, 182, 193)
    MIDNIGHT_BLUE = (25, 25, 112)
    VIOLET_STORM = (148, 0, 211)
    CHROME_SILVER = (192, 192, 192)
    GHOST_WHITE = (248, 248, 255)
    CRIMSON_RED = (220, 20, 60)

def clamp_color(value):
    """Ensure color values are within valid range 0-255"""
    return max(0, min(255, int(value)))

class GameState(Enum):
    MENU = 1
    DIFFICULTY = 2
    TUTORIAL = 3
    PLAYING = 4
    GAME_OVER = 5

class Difficulty(Enum):
    EASY = 1
    NORMAL = 2
    HARD = 3
    INSANE = 4

@dataclass
class Particle:
    x: float
    y: float
    vx: float
    vy: float
    size: float
    color: Tuple[int, int, int]
    life: float
    decay: float
    particle_type: str = "normal"

@dataclass
class PowerUp:
    x: float
    y: float
    radius: float
    rotation: float
    bob_offset: float
    power_type: str = "energy"
    collected: bool = False

class UIElement:
    @staticmethod
    def draw_hologram_button(surface, rect, text, font, active=False, glow_color=None):
        """Draw a holographic button with anime cyberpunk styling"""
        if glow_color is None:
            glow_color = Colors.NEON_CYAN
            
        # Glow effect
        if active:
            glow_surface = pygame.Surface((rect.width + 20, rect.height + 20), pygame.SRCALPHA)
            pygame.draw.rect(glow_surface, (*glow_color, 100), (0, 0, rect.width + 20, rect.height + 20), border_radius=rect.height//2)
            surface.blit(glow_surface, (rect.x - 10, rect.y - 10))
        
        # Main button
        pygame.draw.rect(surface, (*Colors.DEEP_SPACE, 200), rect, border_radius=rect.height//2)
        pygame.draw.rect(surface, glow_color, rect, border_radius=rect.height//2, width=3)
        
        # Inner glow
        inner_rect = pygame.Rect(rect.x + 5, rect.y + 5, rect.width - 10, rect.height - 10)
        pygame.draw.rect(surface, (*glow_color, 50), inner_rect, border_radius=inner_rect.height//2)
        
        # Text
        text_surface = font.render(text, True, Colors.HOLOGRAM_WHITE)
        text_rect = text_surface.get_rect(center=rect.center)
        surface.blit(text_surface, text_rect)
        
        return rect
    
    @staticmethod
    def draw_anime_panel(surface, rect, title="", title_color=None):
        """Draw an anime-style UI panel with holographic effects"""
        if title_color is None:
            title_color = Colors.NEON_CYAN
            
        # Outer glow
        glow_surface = pygame.Surface((rect.width + 30, rect.height + 30), pygame.SRCALPHA)
        pygame.draw.rect(glow_surface, (*title_color, 80), (0, 0, rect.width + 30, rect.height + 30), border_radius=20)
        surface.blit(glow_surface, (rect.x - 15, rect.y - 15))
        
        # Main panel
        pygame.draw.rect(surface, (*Colors.VOID_BLACK, 220), rect, border_radius=15)
        pygame.draw.rect(surface, title_color, rect, border_radius=15, width=4)
        
        # Corner accents
        corner_size = 30
        corners = [
            (rect.x, rect.y),
            (rect.x + rect.width - corner_size, rect.y),
            (rect.x, rect.y + rect.height - corner_size),
            (rect.x + rect.width - corner_size, rect.y + rect.height - corner_size)
        ]
        
        for corner_x, corner_y in corners:
            pygame.draw.rect(surface, (*title_color, 150), (corner_x, corner_y, corner_size, corner_size), border_radius=5)
            pygame.draw.rect(surface, Colors.HOLOGRAM_WHITE, (corner_x + 5, corner_y + 5, corner_size - 10, corner_size - 10), border_radius=3, width=2)

class Bird:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.radius = 22
        self.velocity = 0
        self.gravity = 0.45
        self.jump_strength = -10
        self.boost_strength = -15
        self.trail = []
        self.wing_angle = 0
        self.scroll_velocity = 0
        self.scroll_decay = 0.88
        self.invulnerable = False
        self.invuln_timer = 0
        self.magnetism = 0
        
    def update(self):
        if self.invulnerable:
            self.invuln_timer -= 1
            if self.invuln_timer <= 0:
                self.invulnerable = False
        
        if self.magnetism > 0:
            self.magnetism -= 1
        
        self.velocity += self.scroll_velocity
        self.scroll_velocity *= self.scroll_decay
        
        self.velocity += self.gravity
        self.y += self.velocity
        self.wing_angle += 0.35
        
        self.trail.append((self.x, self.y, self.velocity))
        if len(self.trail) > 20:
            self.trail.pop(0)
        
        if self.y + self.radius > WINDOW_HEIGHT - 100:
            self.y = WINDOW_HEIGHT - 100 - self.radius
            self.velocity = 0
            return not self.invulnerable
        if self.y - self.radius < 0:
            self.y = self.radius
            self.velocity = 0
        return False
    
    def jump(self, boost_active=False):
        strength = self.boost_strength if boost_active else self.jump_strength
        self.velocity = strength
    
    def scroll_control(self, direction):
        scroll_force = 4.5
        if direction > 0:
            self.scroll_velocity = -scroll_force
        elif direction < 0:
            self.scroll_velocity = scroll_force
    
    def activate_shield(self, duration=300):
        self.invulnerable = True
        self.invuln_timer = duration
    
    def activate_magnet(self, duration=600):
        self.magnetism = duration
    
    def draw(self, screen, boost_active=False, frame_count=0):
        # Enhanced anime-style trail
        for i, (tx, ty, vel) in enumerate(self.trail):
            if i > 0:
                alpha = int((i / len(self.trail)) * 200)
                size = max(1, int(self.radius * (i / len(self.trail))))
                
                if size > 1:
                    trail_surface = pygame.Surface((size * 8, size * 8), pygame.SRCALPHA)
                    
                    # Anime-style energy trail colors
                    if boost_active:
                        color = (*Colors.SAKURA_PINK, alpha // 2)
                        accent = (*Colors.VIOLET_STORM, alpha)
                    elif vel < -5:
                        color = (*Colors.ELECTRIC_BLUE, alpha // 2)
                        accent = (*Colors.NEON_CYAN, alpha)
                    elif vel > 5:
                        color = (*Colors.CRIMSON_RED, alpha // 2)
                        accent = (*Colors.ENERGY_RED, alpha)
                    else:
                        color = (*Colors.QUANTUM_GOLD, alpha // 2)
                        accent = (*Colors.PLASMA_ORANGE, alpha)
                    
                    # Outer glow
                    pygame.draw.circle(trail_surface, color, (size * 4, size * 4), size * 3)
                    # Inner core
                    pygame.draw.circle(trail_surface, accent, (size * 4, size * 4), size)
                    # Sparkle effect
                    if random.random() < 0.3:
                        spark_size = max(1, size // 2)
                        pygame.draw.circle(trail_surface, Colors.HOLOGRAM_WHITE, (size * 4, size * 4), spark_size)
                    
                    screen.blit(trail_surface, (tx - size * 4, ty - size * 4))
        
        # Shield effect with anime styling
        if self.invulnerable:
            shield_pulse = math.sin(self.invuln_timer * 0.3) * 0.4 + 0.6
            shield_radius = int((self.radius + 25) * shield_pulse)
            
            # Multiple shield layers
            for layer in range(3):
                layer_radius = shield_radius - layer * 8
                if layer_radius > 0:
                    shield_surface = pygame.Surface((layer_radius * 2, layer_radius * 2), pygame.SRCALPHA)
                    
                    layer_alpha = int((120 - layer * 30) * shield_pulse)
                    shield_color = [Colors.ELECTRIC_BLUE, Colors.NEON_CYAN, Colors.HOLOGRAM_WHITE][layer]
                    
                    pygame.draw.circle(shield_surface, (*shield_color, layer_alpha), 
                                     (layer_radius, layer_radius), layer_radius, 3)
                    
                    screen.blit(shield_surface, (self.x - layer_radius, self.y - layer_radius))
        
        # Magnetism effect - anime energy field
        if self.magnetism > 0:
            mag_pulse = math.sin(self.magnetism * 0.1) * 0.3 + 0.7
            for angle in range(0, 360, 20):
                for ring in range(2, 5):
                    start_x = self.x + math.cos(math.radians(angle + frame_count * 2)) * (self.radius + ring * 8)
                    start_y = self.y + math.sin(math.radians(angle + frame_count * 2)) * (self.radius + ring * 8)
                    end_x = self.x + math.cos(math.radians(angle + frame_count * 2)) * (self.radius + ring * 15) * mag_pulse
                    end_y = self.y + math.sin(math.radians(angle + frame_count * 2)) * (self.radius + ring * 15) * mag_pulse
                    
                    line_alpha = max(0, min(255, int((100 - ring * 15) * mag_pulse)))
                    if line_alpha > 0:
                        pygame.draw.line(screen, (*Colors.VIOLET_STORM, line_alpha), 
                                       (start_x, start_y), (end_x, end_y), 2)
        
        # Enhanced boost effect - anime power-up style
        if boost_active:
            boost_pulse = math.sin(frame_count * 0.2) * 0.4 + 0.6
            
            # Multiple energy rings
            for ring in range(4):
                ring_radius = int((self.radius + 30 + ring * 10) * boost_pulse)
                ring_surface = pygame.Surface((ring_radius * 2, ring_radius * 2), pygame.SRCALPHA)
                
                ring_alpha = int((150 - ring * 30) * boost_pulse)
                ring_colors = [Colors.SAKURA_PINK, Colors.VIOLET_STORM, Colors.NEON_PINK, Colors.HOLOGRAM_WHITE]
                
                pygame.draw.circle(ring_surface, (*ring_colors[ring], ring_alpha), 
                                 (ring_radius, ring_radius), ring_radius, 4)
                
                screen.blit(ring_surface, (self.x - ring_radius, self.y - ring_radius))
        
        # Anime-style bird body
        main_color = Colors.SAKURA_PINK if boost_active else Colors.NEON_CYAN
        
        # Energy field layers
        field_pulse = math.sin(frame_count * 0.1) * 0.2 + 0.8
        for r in range(self.radius + 10, self.radius, -3):
            alpha = int((1 - (r - self.radius) / 10) * 80 * field_pulse)
            field_surface = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(field_surface, (*main_color, alpha), (r, r), r, 2)
            screen.blit(field_surface, (self.x - r, self.y - r))
        
        # Main body with gradient
        pygame.draw.circle(screen, main_color, (int(self.x), int(self.y)), self.radius + 4)
        pygame.draw.circle(screen, Colors.QUANTUM_GOLD, (int(self.x), int(self.y)), self.radius + 1)
        pygame.draw.circle(screen, Colors.HOLOGRAM_WHITE, (int(self.x), int(self.y)), self.radius - 2)
        pygame.draw.circle(screen, Colors.ELECTRIC_BLUE, (int(self.x), int(self.y)), self.radius - 6)
        
        # Anime-style core with sparkle
        core_pulse = math.sin(frame_count * 0.3) * 0.3 + 0.7
        core_size = int(8 * core_pulse)
        pygame.draw.circle(screen, Colors.HOLOGRAM_WHITE, (int(self.x), int(self.y)), core_size + 3)
        pygame.draw.circle(screen, main_color, (int(self.x), int(self.y)), core_size)
        
        # Animated wings
        wing_offset = math.sin(self.wing_angle) * 15
        wing_points = [
            (self.x - 28, self.y + wing_offset),
            (self.x - 45, self.y - 15 + wing_offset),
            (self.x - 35, self.y - 25 + wing_offset),
            (self.x - 18, self.y - 12 + wing_offset)
        ]
        
        # Wing gradient effect
        pygame.draw.polygon(screen, Colors.PLASMA_ORANGE, wing_points)
        pygame.draw.polygon(screen, main_color, wing_points, 3)
        
        # Anime-style eye
        eye_glow_surface = pygame.Surface((20, 20), pygame.SRCALPHA)
        pygame.draw.circle(eye_glow_surface, (*Colors.NEON_CYAN, 100), (10, 10), 10)
        screen.blit(eye_glow_surface, (self.x + 7, self.y - 13))
        
        pygame.draw.circle(screen, Colors.HOLOGRAM_WHITE, (int(self.x + 12), int(self.y - 8)), 9)
        pygame.draw.circle(screen, Colors.ELECTRIC_BLUE, (int(self.x + 12), int(self.y - 8)), 7)
        pygame.draw.circle(screen, Colors.NEON_CYAN, (int(self.x + 13), int(self.y - 8)), 5)
        pygame.draw.circle(screen, Colors.HOLOGRAM_WHITE, (int(self.x + 15), int(self.y - 10)), 2)
        
        # Futuristic beak
        beak_points = [
            (self.x + 28, self.y - 6),
            (self.x + 46, self.y),
            (self.x + 28, self.y + 6)
        ]
        pygame.draw.polygon(screen, main_color, beak_points)
        pygame.draw.polygon(screen, Colors.HOLOGRAM_WHITE, beak_points, 2)

class Pipe:
    def __init__(self, x, difficulty=Difficulty.NORMAL):
        self.x = x
        self.width = 85
        
        # Difficulty-based parameters
        gap_sizes = {
            Difficulty.EASY: 240,
            Difficulty.NORMAL: 200,
            Difficulty.HARD: 160,
            Difficulty.INSANE: 130
        }
        
        speed_multipliers = {
            Difficulty.EASY: 0.7,
            Difficulty.NORMAL: 1.0,
            Difficulty.HARD: 1.4,
            Difficulty.INSANE: 2.0
        }
        
        gap_size = gap_sizes[difficulty]
        min_height = 100
        max_height = WINDOW_HEIGHT - gap_size - 120 - min_height
        self.top_height = random.randint(min_height, max_height)
        self.bottom_y = self.top_height + gap_size
        self.scored = False
        self.energy_pulse = 0
        self.speed = 3.5 * speed_multipliers[difficulty]
        self.difficulty = difficulty
        
    def update(self):
        self.x -= self.speed
        self.energy_pulse += 0.15
        
    def draw(self, screen):
        pulse = math.sin(self.energy_pulse) * 0.3 + 0.7
        
        # Difficulty-based colors
        difficulty_colors = {
            Difficulty.EASY: (Colors.MATRIX_GREEN, Colors.NEON_GREEN),
            Difficulty.NORMAL: (Colors.ELECTRIC_BLUE, Colors.NEON_CYAN),
            Difficulty.HARD: (Colors.LASER_PURPLE, Colors.VIOLET_STORM),
            Difficulty.INSANE: (Colors.ENERGY_RED, Colors.CRIMSON_RED)
        }
        
        base_color, accent_color = difficulty_colors[self.difficulty]
        
        # Enhanced anime-style energy aura
        aura_surface = pygame.Surface((self.width + 60, WINDOW_HEIGHT), pygame.SRCALPHA)
        for layer in range(5):
            layer_alpha = int((50 - layer * 8) * pulse)
            layer_width = self.width + (layer + 1) * 12
            
            pygame.draw.rect(aura_surface, (*base_color, layer_alpha), 
                           (30 - layer * 6, 0, layer_width, self.top_height))
            pygame.draw.rect(aura_surface, (*base_color, layer_alpha), 
                           (30 - layer * 6, self.bottom_y, layer_width, WINDOW_HEIGHT - self.bottom_y))
        
        screen.blit(aura_surface, (self.x - 30, 0))
        
        # Animated pipe body with scan lines
        for i in range(self.width):
            gradient_ratio = i / self.width
            r = base_color[0] * (1 - gradient_ratio) + accent_color[0] * gradient_ratio
            g = base_color[1] * (1 - gradient_ratio) + accent_color[1] * gradient_ratio
            b = base_color[2] * (1 - gradient_ratio) + accent_color[2] * gradient_ratio
            
            # Energy animation
            energy_mod = 25 * math.sin(self.energy_pulse * 2 + i * 0.1)
            r = clamp_color(r + energy_mod)
            g = clamp_color(g + energy_mod)
            b = clamp_color(b + energy_mod)
            
            # Main pipe body
            pygame.draw.rect(screen, (r, g, b), (self.x + i, 0, 3, self.top_height))
            pygame.draw.rect(screen, (r, g, b), (self.x + i, self.bottom_y, 3, WINDOW_HEIGHT - self.bottom_y))
            
            # Scan lines effect
            if i % 5 == 0:
                scan_alpha = max(0, min(255, int(abs(100 * math.sin(self.energy_pulse + i * 0.2)))))
                if scan_alpha > 0:
                    pygame.draw.rect(screen, (*Colors.HOLOGRAM_WHITE, scan_alpha), 
                                   (self.x + i, 0, 1, self.top_height))
                    pygame.draw.rect(screen, (*Colors.HOLOGRAM_WHITE, scan_alpha), 
                                   (self.x + i, self.bottom_y, 1, WINDOW_HEIGHT - self.bottom_y))
        
        # Enhanced caps with anime styling
        cap_height = 30
        cap_surface = pygame.Surface((self.width + 40, cap_height + 10), pygame.SRCALPHA)
        
        # Outer glow
        pygame.draw.rect(cap_surface, (*accent_color, int(150 * pulse)), 
                        (0, 5, self.width + 40, cap_height), border_radius=15)
        # Main cap
        pygame.draw.rect(cap_surface, (*accent_color, 240), 
                        (10, 5, self.width + 20, cap_height), border_radius=12)
        # Inner highlight
        pygame.draw.rect(cap_surface, (*Colors.HOLOGRAM_WHITE, int(200 * pulse)), 
                        (15, 10, self.width + 10, cap_height - 10), border_radius=10)
        
        screen.blit(cap_surface, (self.x - 20, self.top_height - cap_height - 5))
        screen.blit(cap_surface, (self.x - 20, self.bottom_y))
    
    def collides_with(self, bird):
        if (bird.x + bird.radius - 12 > self.x and 
            bird.x - bird.radius + 12 < self.x + self.width):
            if (bird.y - bird.radius + 10 < self.top_height or 
                bird.y + bird.radius - 10 > self.bottom_y):
                return not bird.invulnerable
        return False

class BoostSystem:
    def __init__(self):
        self.charge = 100
        self.max_charge = 100
        self.active = False
        self.cooldown = 0
        
    def use_boost(self):
        if self.charge >= 30 and not self.active:
            self.charge -= 30
            self.active = True
            self.cooldown = 25
            return True
        return False
    
    def update(self):
        if self.active:
            self.cooldown -= 1
            if self.cooldown <= 0:
                self.active = False
        
        # Gradual recharge
        if self.charge < self.max_charge and not self.active:
            self.charge += 0.1
    
    def add_charge(self, amount):
        self.charge = min(self.max_charge, self.charge + amount)

class ParticleSystem:
    def __init__(self):
        self.particles = []
    
    def add_particle(self, x, y, color=None, particle_type="normal", count=10):
        if color is None:
            color = Colors.NEON_CYAN
        
        for _ in range(count):
            self.particles.append(Particle(
                x=x + random.uniform(-15, 15),
                y=y + random.uniform(-15, 15),
                vx=random.uniform(-8, 8),
                vy=random.uniform(-8, 8),
                size=random.uniform(2, 12),
                color=color,
                life=1.5,
                decay=random.uniform(0.01, 0.05),
                particle_type=particle_type
            ))
    
    def update(self):
        for particle in self.particles[:]:
            particle.x += particle.vx
            particle.y += particle.vy
            particle.vy += 0.15
            particle.vx *= 0.96
            particle.life -= particle.decay
            
            if particle.life <= 0:
                self.particles.remove(particle)
    
    def draw(self, screen):
        for particle in self.particles:
            if particle.life > 0:
                alpha = max(0, min(255, int(particle.life * 255)))
                size = max(1, int(particle.size))
                
                particle_surface = pygame.Surface((size * 6, size * 6), pygame.SRCALPHA)
                # Outer glow
                pygame.draw.circle(particle_surface, (*particle.color, alpha // 3), 
                                 (size * 3, size * 3), size * 3)
                # Main particle
                pygame.draw.circle(particle_surface, (*particle.color, alpha), 
                                 (size * 3, size * 3), size)
                # Core sparkle
                if size > 2:
                    pygame.draw.circle(particle_surface, (*Colors.HOLOGRAM_WHITE, alpha), 
                                     (size * 3, size * 3), max(1, size // 2))
                
                screen.blit(particle_surface, (particle.x - size * 3, particle.y - size * 3))

class FlappyBirdGame:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Quantum Flappy Bird - Cyberpunk Edition")
        self.clock = pygame.time.Clock()
        
        self.bird = Bird(250, WINDOW_HEIGHT // 2)
        self.pipes = []
        self.power_ups = []
        self.boost_system = BoostSystem()
        self.particle_system = ParticleSystem()
        
        self.state = GameState.MENU
        self.difficulty = Difficulty.NORMAL
        self.score = 0
        self.best_score = self.load_best_score()
        self.frame_count = 0
        self.pipe_timer = 0
        self.start_time = 0
        
        self.stats = {
            'boosts_used': 0,
            'best_streak': 0,
            'current_streak': 0,
            'flight_time': 0,
            'powerups_collected': 0
        }
        
        # Enhanced fonts for anime styling
        self.mega_font = pygame.font.Font(None, 108)
        self.title_font = pygame.font.Font(None, 84)
        self.large_font = pygame.font.Font(None, 52)
        self.medium_font = pygame.font.Font(None, 40)
        self.small_font = pygame.font.Font(None, 28)
        
        self.stars = []
        self.setup_stars()
        
        self.achievement_text = ""
        self.achievement_timer = 0
        
    def setup_stars(self):
        for _ in range(300):
            self.stars.append({
                'x': random.uniform(0, WINDOW_WIDTH),
                'y': random.uniform(0, WINDOW_HEIGHT),
                'size': random.uniform(0.5, 6),
                'speed': random.uniform(0.2, 4.0),
                'twinkle': random.uniform(0, math.pi * 2),
                'brightness': random.uniform(0.3, 1.0),
                'color': random.choice([Colors.HOLOGRAM_WHITE, Colors.NEON_CYAN, Colors.SAKURA_PINK, Colors.ELECTRIC_BLUE])
            })
    
    def update_stars(self):
        for star in self.stars:
            star['x'] -= star['speed'] * (1 + self.frame_count * 0.0001)
            star['twinkle'] += 0.15
            
            if star['x'] < -15:
                star['x'] = WINDOW_WIDTH + 15
                star['y'] = random.uniform(0, WINDOW_HEIGHT)
    
    def draw_background(self, screen):
        # Enhanced cyberpunk gradient
        for y in range(WINDOW_HEIGHT):
            color_ratio = y / WINDOW_HEIGHT
            time_offset = self.frame_count * 0.003
            
            # Multiple sine waves for complex color patterns
            r = clamp_color(5 + math.sin(time_offset + color_ratio * 3) * 8 + math.sin(time_offset * 1.5) * 4)
            g = clamp_color(5 + math.sin(time_offset * 0.8 + color_ratio * 2) * 10 + math.sin(time_offset * 2.1) * 5)
            b = clamp_color(15 + math.sin(time_offset * 0.4 + color_ratio * 1.5) * 20 + math.sin(time_offset * 0.7) * 8)
            
            pygame.draw.line(screen, (r, g, b), (0, y), (WINDOW_WIDTH, y))
        
        # Enhanced starfield with different types
        for star in self.stars:
            brightness = star['brightness'] * (math.sin(star['twinkle']) * 0.5 + 0.5)
            alpha = int(brightness * 255)
            size = max(0.5, star['size'] * brightness)
            
            if size > 0.5:
                star_surface = pygame.Surface((int(size * 6), int(size * 6)), pygame.SRCALPHA)
                
                # Different star types
                if size > 3:
                    # Cross pattern for larger stars
                    cross_length = int(size * 2.5)
                    pygame.draw.line(star_surface, (*star['color'], alpha), 
                                   (size * 3 - cross_length, size * 3), 
                                   (size * 3 + cross_length, size * 3), 3)
                    pygame.draw.line(star_surface, (*star['color'], alpha), 
                                   (size * 3, size * 3 - cross_length), 
                                   (size * 3, size * 3 + cross_length), 3)
                
                # Main star body
                pygame.draw.circle(star_surface, (*star['color'], alpha), 
                                 (int(size * 3), int(size * 3)), int(size))
                
                # Inner sparkle
                if size > 1:
                    pygame.draw.circle(star_surface, (*Colors.HOLOGRAM_WHITE, alpha), 
                                     (int(size * 3), int(size * 3)), max(1, int(size * 0.6)))
                
                screen.blit(star_surface, (star['x'] - size * 3, star['y'] - size * 3))
    
    def load_best_score(self):
        try:
            if os.path.exists('quantum_flappy_save.json'):
                with open('quantum_flappy_save.json', 'r') as f:
                    data = json.load(f)
                    return data.get('best_score', 0)
        except:
            pass
        return 0
    
    def save_game_data(self):
        try:
            with open('quantum_flappy_save.json', 'w') as f:
                json.dump({'best_score': self.best_score, 'stats': self.stats}, f)
        except:
            pass
    
    def show_achievement(self, text):
        self.achievement_text = text
        self.achievement_timer = 200
    
    def spawn_pipe(self):
        self.pipes.append(Pipe(WINDOW_WIDTH, self.difficulty))
        
        # Power-up spawn chance based on difficulty
        spawn_chances = {
            Difficulty.EASY: 0.8,
            Difficulty.NORMAL: 0.7,
            Difficulty.HARD: 0.6,
            Difficulty.INSANE: 0.5
        }
        
        if random.random() < spawn_chances[self.difficulty] and len(self.pipes) > 0:
            last_pipe = self.pipes[-1]
            gap_center = last_pipe.top_height + (last_pipe.bottom_y - last_pipe.top_height) // 2
            
            self.power_ups.append(PowerUp(
                x=last_pipe.x + last_pipe.width // 2,
                y=gap_center + random.uniform(-40, 40),
                radius=25,
                rotation=0,
                bob_offset=random.uniform(0, math.pi * 2),
                power_type=random.choice(["energy", "shield", "magnet"])
            ))
    
    def update_power_ups(self):
        for power_up in self.power_ups[:]:
            power_up.x -= 3.5
            power_up.rotation += 0.3
            power_up.y += math.sin(self.frame_count * 0.08 + power_up.bob_offset) * 3
            
            # Enhanced magnetism effect
            if self.bird.magnetism > 0:
                dx = self.bird.x - power_up.x
                dy = self.bird.y - power_up.y
                distance = math.sqrt(dx*dx + dy*dy)
                
                if distance < 150 and distance > 0:
                    pull_strength = (150 - distance) / 150 * 4
                    power_up.x += (dx / distance) * pull_strength
                    power_up.y += (dy / distance) * pull_strength
            
            # Collection with enhanced effects
            dist = math.sqrt((self.bird.x - power_up.x)**2 + (self.bird.y - power_up.y)**2)
            if dist < self.bird.radius + power_up.radius and not power_up.collected:
                power_up.collected = True
                self.stats['powerups_collected'] += 1
                
                if power_up.power_type == "energy":
                    self.boost_system.add_charge(70)
                    self.show_achievement("ENERGY CORE ABSORBED")
                elif power_up.power_type == "shield":
                    self.bird.activate_shield(700)
                    self.show_achievement("SHIELD MATRIX ONLINE")
                elif power_up.power_type == "magnet":
                    self.bird.activate_magnet(1000)
                    self.show_achievement("MAGNETIC FIELD ACTIVE")
                
                self.particle_system.add_particle(power_up.x, power_up.y, Colors.HOLOGRAM_WHITE, "energy", 35)
            
            if power_up.x < -power_up.radius or power_up.collected:
                self.power_ups.remove(power_up)
    
    def draw_power_ups(self, screen):
        for power_up in self.power_ups:
            colors = {
                "energy": Colors.QUANTUM_GOLD,
                "shield": Colors.ELECTRIC_BLUE,
                "magnet": Colors.VIOLET_STORM
            }
            color = colors.get(power_up.power_type, Colors.NEON_CYAN)
            
            pulse = math.sin(self.frame_count * 0.25) * 0.4 + 0.6
            glow_radius = int((power_up.radius + 35) * pulse)
            
            # Enhanced glow with multiple layers
            for layer in range(3):
                layer_radius = glow_radius - layer * 12
                if layer_radius > 0:
                    glow_surface = pygame.Surface((layer_radius * 2, layer_radius * 2), pygame.SRCALPHA)
                    layer_alpha = int((150 - layer * 40) * pulse)
                    pygame.draw.circle(glow_surface, (*color, layer_alpha), 
                                     (layer_radius, layer_radius), layer_radius)
                    screen.blit(glow_surface, (power_up.x - layer_radius, power_up.y - layer_radius))
            
            # Enhanced shapes based on type
            if power_up.power_type == "energy":
                # Animated star shape
                points = []
                for i in range(16):
                    angle = (i * math.pi / 8) + power_up.rotation
                    radius = (power_up.radius if i % 2 == 0 else power_up.radius * 0.6) * pulse
                    x = power_up.x + math.cos(angle) * radius
                    y = power_up.y + math.sin(angle) * radius
                    points.append((x, y))
                
                if len(points) >= 3:
                    pygame.draw.polygon(screen, color, points)
                    pygame.draw.circle(screen, Colors.HOLOGRAM_WHITE, 
                                     (int(power_up.x), int(power_up.y)), 
                                     max(1, int(power_up.radius * 0.5 * pulse)))
            
            elif power_up.power_type == "shield":
                # Hexagonal shield
                points = []
                for i in range(6):
                    angle = (i * math.pi / 3) + power_up.rotation
                    radius = power_up.radius * pulse
                    x = power_up.x + math.cos(angle) * radius
                    y = power_up.y + math.sin(angle) * radius
                    points.append((x, y))
                
                if len(points) >= 3:
                    pygame.draw.polygon(screen, color, points, 5)
                    pygame.draw.polygon(screen, Colors.HOLOGRAM_WHITE, points, 2)
            
            else:  # magnet
                # Animated magnetic field rings
                for ring in range(3):
                    ring_radius = int((power_up.radius + ring * 8) * pulse)
                    ring_alpha = int((200 - ring * 50) * pulse)
                    ring_surface = pygame.Surface((ring_radius * 2, ring_radius * 2), pygame.SRCALPHA)
                    pygame.draw.circle(ring_surface, (*color, ring_alpha), 
                                     (ring_radius, ring_radius), ring_radius, 4)
                    screen.blit(ring_surface, (power_up.x - ring_radius, power_up.y - ring_radius))
    
    def update_pipes(self):
        self.pipe_timer += 1
        
        # Difficulty-based spawn timing
        spawn_timers = {
            Difficulty.EASY: 180,
            Difficulty.NORMAL: 150,
            Difficulty.HARD: 120,
            Difficulty.INSANE: 90
        }
        
        if self.pipe_timer >= spawn_timers[self.difficulty]:
            self.pipe_timer = 0
            self.spawn_pipe()
        
        for pipe in self.pipes[:]:
            pipe.update()
            
            if not pipe.scored and pipe.x + pipe.width < self.bird.x:
                pipe.scored = True
                self.score += 1
                self.stats['current_streak'] += 1
                
                if self.stats['current_streak'] > self.stats['best_streak']:
                    self.stats['best_streak'] = self.stats['current_streak']
                
                self.particle_system.add_particle(self.bird.x, self.bird.y - 40, Colors.MATRIX_GREEN, "energy", 20)
                
                if self.score % 10 == 0:
                    self.show_achievement(f"MILESTONE: {self.score} POINTS")
                
                if self.score > self.best_score:
                    self.show_achievement("NEW RECORD ACHIEVED")
                    self.best_score = self.score
                    self.save_game_data()
            
            if pipe.collides_with(self.bird):
                self.end_game()
            
            if pipe.x + pipe.width < 0:
                self.pipes.remove(pipe)
    
    def draw_ground(self, screen):
        ground_height = 120
        ground_y = WINDOW_HEIGHT - ground_height
        
        # Enhanced ground with anime-style energy grid
        for y in range(ground_height):
            ratio = y / ground_height
            r = clamp_color(Colors.VOID_BLACK[0] + (Colors.DEEP_SPACE[0] - Colors.VOID_BLACK[0]) * ratio)
            g = clamp_color(Colors.VOID_BLACK[1] + (Colors.DEEP_SPACE[1] - Colors.VOID_BLACK[1]) * ratio)
            b = clamp_color(Colors.VOID_BLACK[2] + (Colors.DEEP_SPACE[2] - Colors.VOID_BLACK[2]) * ratio)
            pygame.draw.line(screen, (r, g, b), (0, ground_y + y), (WINDOW_WIDTH, ground_y + y))
        
        # Animated energy grid
        grid_alpha = int(120 + math.sin(self.frame_count * 0.1) * 60)
        grid_flow = self.frame_count % 80
        
        # Vertical lines with flow effect
        for x in range(0, WINDOW_WIDTH, 50):
            grid_x = x + grid_flow
            if grid_x < WINDOW_WIDTH:
                pygame.draw.line(screen, (*Colors.NEON_CYAN, grid_alpha), 
                               (grid_x, ground_y), (grid_x, WINDOW_HEIGHT), 3)
        
        # Horizontal lines
        for y in range(0, ground_height, 25):
            line_alpha = int(grid_alpha * (1 - y / ground_height))
            pygame.draw.line(screen, (*Colors.ELECTRIC_BLUE, line_alpha), 
                           (0, ground_y + y), (WINDOW_WIDTH, ground_y + y), 2)
    
    def draw_hud(self, screen):
        # More transparent HUD background
        hud_surface = pygame.Surface((WINDOW_WIDTH, 160), pygame.SRCALPHA)
        pygame.draw.rect(hud_surface, (*Colors.VOID_BLACK, 60), (0, 0, WINDOW_WIDTH, 160))
        pygame.draw.rect(hud_surface, (*Colors.ELECTRIC_BLUE, 40), (0, 155, WINDOW_WIDTH, 5))
        screen.blit(hud_surface, (0, 0))
        
        # More transparent score display
        score_rect = pygame.Rect(40, 25, 350, 90)
        score_surface = pygame.Surface((score_rect.width, score_rect.height), pygame.SRCALPHA)
        pygame.draw.rect(score_surface, (*Colors.DEEP_SPACE, 120), (0, 0, score_rect.width, score_rect.height), border_radius=40)
        pygame.draw.rect(score_surface, (*Colors.NEON_CYAN, 80), (0, 0, score_rect.width, score_rect.height), border_radius=40, width=3)
        screen.blit(score_surface, score_rect)
        
        score_text = self.large_font.render(f"SCORE: {self.score:04d}", True, Colors.HOLOGRAM_WHITE)
        score_glow = pygame.Surface(score_text.get_size(), pygame.SRCALPHA)
        glow_text = self.large_font.render(f"SCORE: {self.score:04d}", True, (*Colors.QUANTUM_GOLD, 60))
        
        for offset in [(2, 2), (-2, -2), (2, -2), (-2, 2)]:
            score_glow.blit(glow_text, offset)
        score_glow.blit(score_text, (0, 0))
        
        score_text_rect = score_glow.get_rect(center=score_rect.center)
        screen.blit(score_glow, score_text_rect)
        
        # More transparent boost system display
        boost_rect = pygame.Rect(WINDOW_WIDTH - 450, 25, 410, 130)
        boost_surface = pygame.Surface((boost_rect.width, boost_rect.height), pygame.SRCALPHA)
        pygame.draw.rect(boost_surface, (*Colors.DEEP_SPACE, 120), (0, 0, boost_rect.width, boost_rect.height), border_radius=60)
        pygame.draw.rect(boost_surface, (*Colors.VIOLET_STORM, 80), (0, 0, boost_rect.width, boost_rect.height), border_radius=60, width=4)
        screen.blit(boost_surface, boost_rect)
        
        # Multi-layered energy bar
        bar_width = 340
        bar_height = 35
        bar_x = boost_rect.x + 35
        bar_y = boost_rect.y + 55
        
        # More transparent background
        pygame.draw.rect(screen, (*Colors.VOID_BLACK, 120), 
                        (bar_x - 8, bar_y - 8, bar_width + 16, bar_height + 16), border_radius=25)
        pygame.draw.rect(screen, (*Colors.ELECTRIC_BLUE, 80), 
                        (bar_x - 3, bar_y - 3, bar_width + 6, bar_height + 6), border_radius=20)
        
        # Energy fill with animated flow
        fill_width = int((self.boost_system.charge / self.boost_system.max_charge) * (bar_width - 8))
        
        if fill_width > 0:
            # Determine color based on charge level
            if self.boost_system.charge >= 80:
                energy_color = Colors.QUANTUM_GOLD
            elif self.boost_system.charge >= 50:
                energy_color = Colors.ELECTRIC_BLUE
            elif self.boost_system.charge >= 30:
                energy_color = Colors.PLASMA_ORANGE
            else:
                energy_color = Colors.ENERGY_RED
            
            # Animated energy flow
            energy_surface = pygame.Surface((fill_width, bar_height - 8), pygame.SRCALPHA)
            for x in range(fill_width):
                flow_intensity = math.sin(self.frame_count * 0.3 + x * 0.15) * 0.4 + 0.6
                flow_color = tuple(clamp_color(c * flow_intensity) for c in energy_color)
                
                # Vertical gradient
                for y in range(bar_height - 8):
                    gradient_factor = 1.0 - (abs(y - (bar_height - 8) // 2) / ((bar_height - 8) // 2)) * 0.3
                    final_color = tuple(clamp_color(c * gradient_factor) for c in flow_color)
                    energy_surface.set_at((x, y), final_color)
            
            screen.blit(energy_surface, (bar_x + 4, bar_y + 4))
        
        # Status text with glow
        if self.boost_system.charge >= 30:
            status_text = "BOOST READY"
            status_color = Colors.QUANTUM_GOLD
        elif self.boost_system.charge > 0:
            status_text = f"ENERGY: {int(self.boost_system.charge)}%"
            status_color = Colors.ELECTRIC_BLUE
        else:
            status_text = "ENERGY DEPLETED"
            status_color = Colors.ENERGY_RED
        
        status_surface = self.medium_font.render(status_text, True, status_color)
        status_rect = status_surface.get_rect(center=(boost_rect.centerx, boost_rect.y + 25))
        screen.blit(status_surface, status_rect)
        
        # Difficulty indicator
        difficulty_colors = {
            Difficulty.EASY: Colors.MATRIX_GREEN,
            Difficulty.NORMAL: Colors.ELECTRIC_BLUE,
            Difficulty.HARD: Colors.PLASMA_ORANGE,
            Difficulty.INSANE: Colors.ENERGY_RED
        }
        
        diff_text = f"MODE: {self.difficulty.name}"
        diff_surface = self.small_font.render(diff_text, True, difficulty_colors[self.difficulty])
        screen.blit(diff_surface, (boost_rect.x + 10, boost_rect.y + 100))
        
        # More transparent achievement notification
        if self.achievement_timer > 0:
            notif_width = 500
            notif_height = 80
            notif_rect = pygame.Rect(WINDOW_WIDTH - notif_width - 30, 200, notif_width, notif_height)
            
            notif_surface = pygame.Surface((notif_width, notif_height), pygame.SRCALPHA)
            alpha_factor = min(1, self.achievement_timer / 80)
            pygame.draw.rect(notif_surface, (*Colors.DEEP_SPACE, int(100 * alpha_factor)), (0, 0, notif_width, notif_height), border_radius=35)
            pygame.draw.rect(notif_surface, (*Colors.SAKURA_PINK, int(120 * alpha_factor)), (0, 0, notif_width, notif_height), border_radius=35, width=4)
            screen.blit(notif_surface, notif_rect)
            
            notif_text = self.medium_font.render(self.achievement_text, True, Colors.HOLOGRAM_WHITE)
            notif_text_rect = notif_text.get_rect(center=notif_rect.center)
            screen.blit(notif_text, notif_text_rect)
            
            self.achievement_timer -= 1
    
    def draw_menu(self, screen):
        self.draw_background(screen)
        self.draw_ground(screen)
        
        # Enhanced title with glow effect
        title_surface = pygame.Surface((WINDOW_WIDTH, 300), pygame.SRCALPHA)
        
        # Title glow
        for offset in range(5, 0, -1):
            glow_alpha = int(50 - offset * 8)
            title_glow = self.mega_font.render("QUANTUM FLAPPY", True, (*Colors.NEON_CYAN, glow_alpha))
            title_rect = title_glow.get_rect(center=(WINDOW_WIDTH // 2, 150 + offset))
            title_surface.blit(title_glow, title_rect)
        
        # Main title
        title_text = self.mega_font.render("QUANTUM FLAPPY", True, Colors.HOLOGRAM_WHITE)
        title_rect = title_text.get_rect(center=(WINDOW_WIDTH // 2, 150))
        title_surface.blit(title_text, title_rect)
        
        screen.blit(title_surface, (0, 50))
        
        # Animated subtitle
        pulse = math.sin(self.frame_count * 0.1) * 0.3 + 0.7
        subtitle_color = tuple(int(c * pulse) for c in Colors.SAKURA_PINK)
        subtitle_text = self.large_font.render("CYBERPUNK EDITION", True, subtitle_color)
        subtitle_rect = subtitle_text.get_rect(center=(WINDOW_WIDTH // 2, 250))
        screen.blit(subtitle_text, subtitle_rect)
        
        # Enhanced menu buttons
        button_width, button_height = 400, 70
        buttons = [
            ("START QUANTUM FLIGHT", Colors.MATRIX_GREEN, 380),
            ("DIFFICULTY MATRIX", Colors.ELECTRIC_BLUE, 470),
            ("PILOT TRAINING", Colors.VIOLET_STORM, 560),
            ("SYSTEM EXIT", Colors.ENERGY_RED, 650)
        ]
        
        button_rects = {}
        for i, (text, color, y) in enumerate(buttons):
            button_rect = pygame.Rect(WINDOW_WIDTH // 2 - button_width // 2, y, button_width, button_height)
            mouse_pos = pygame.mouse.get_pos()
            is_hovered = button_rect.collidepoint(mouse_pos)
            
            UIElement.draw_hologram_button(screen, button_rect, text, self.medium_font, is_hovered, color)
            button_rects[i] = button_rect
        
        # Stats display
        if self.best_score > 0:
            stats_panel = pygame.Rect(WINDOW_WIDTH // 2 - 200, 750, 400, 100)
            UIElement.draw_anime_panel(screen, stats_panel, "", Colors.QUANTUM_GOLD)
            
            stats_text = self.medium_font.render(f"BEST SCORE: {self.best_score:04d}", True, Colors.HOLOGRAM_WHITE)
            stats_rect = stats_text.get_rect(center=stats_panel.center)
            screen.blit(stats_text, stats_rect)
        
        return button_rects
    
    def draw_difficulty_select(self, screen):
        self.draw_background(screen)
        self.draw_ground(screen)
        
        # Difficulty selection panel
        panel_width, panel_height = 800, 600
        panel_rect = pygame.Rect(WINDOW_WIDTH // 2 - panel_width // 2, WINDOW_HEIGHT // 2 - panel_height // 2, panel_width, panel_height)
        UIElement.draw_anime_panel(screen, panel_rect, "DIFFICULTY_MATRIX", Colors.ELECTRIC_BLUE)
        
        # Title
        title_text = self.title_font.render("SELECT DIFFICULTY", True, Colors.HOLOGRAM_WHITE)
        title_rect = title_text.get_rect(center=(panel_rect.centerx, panel_rect.y + 80))
        screen.blit(title_text, title_rect)
        
        # Difficulty buttons
        difficulties = [
            (Difficulty.EASY, "EASY MODE", "Larger gaps, slower speed", Colors.MATRIX_GREEN),
            (Difficulty.NORMAL, "NORMAL MODE", "Standard challenge", Colors.ELECTRIC_BLUE),
            (Difficulty.HARD, "HARD MODE", "Smaller gaps, faster speed", Colors.PLASMA_ORANGE),
            (Difficulty.INSANE, "INSANE MODE", "Maximum challenge", Colors.ENERGY_RED)
        ]
        
        button_rects = {}
        for i, (diff, title, desc, color) in enumerate(difficulties):
            button_rect = pygame.Rect(panel_rect.x + 50, panel_rect.y + 150 + i * 100, panel_width - 100, 80)
            mouse_pos = pygame.mouse.get_pos()
            is_selected = self.difficulty == diff
            is_hovered = button_rect.collidepoint(mouse_pos)
            
            # Enhanced button with selection indicator
            if is_selected:
                selection_glow = pygame.Surface((button_rect.width + 20, button_rect.height + 20), pygame.SRCALPHA)
                pygame.draw.rect(selection_glow, (*color, 100), (0, 0, button_rect.width + 20, button_rect.height + 20), border_radius=40)
                screen.blit(selection_glow, (button_rect.x - 10, button_rect.y - 10))
            
            UIElement.draw_hologram_button(screen, button_rect, title, self.medium_font, is_hovered or is_selected, color)
            
            # Description text
            desc_surface = self.small_font.render(desc, True, Colors.CHROME_SILVER)
            desc_rect = desc_surface.get_rect(center=(button_rect.centerx, button_rect.bottom + 15))
            screen.blit(desc_surface, desc_rect)
            
            button_rects[diff] = button_rect
        
        # Back button
        back_rect = pygame.Rect(panel_rect.x + 50, panel_rect.bottom - 80, 150, 50)
        UIElement.draw_hologram_button(screen, back_rect, "BACK", self.small_font, False, Colors.CHROME_SILVER)
        button_rects['back'] = back_rect
        
        return button_rects
    
    def draw_tutorial(self, screen):
        self.draw_background(screen)
        self.draw_ground(screen)
        
        # Tutorial overlay
        overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        pygame.draw.rect(overlay, (*Colors.VOID_BLACK, 180), (0, 0, WINDOW_WIDTH, WINDOW_HEIGHT))
        screen.blit(overlay, (0, 0))
        
        panel_width, panel_height = 900, 700
        panel_rect = pygame.Rect(WINDOW_WIDTH // 2 - panel_width // 2, WINDOW_HEIGHT // 2 - panel_height // 2, panel_width, panel_height)
        UIElement.draw_anime_panel(screen, panel_rect, "PILOT_TRAINING", Colors.VIOLET_STORM)
        
        y_offset = panel_rect.y + 60
        
        # Enhanced title
        title_text = self.title_font.render("QUANTUM FLIGHT PROTOCOL", True, Colors.HOLOGRAM_WHITE)
        title_rect = title_text.get_rect(center=(panel_rect.centerx, y_offset))
        screen.blit(title_text, title_rect)
        y_offset += 100
        
        # Tutorial sections with anime styling
        sections = [
            ("BASIC NAVIGATION", Colors.NEON_CYAN, [
                "SPACE/CLICK: Standard quantum propulsion",
                "SHIFT + SPACE/CLICK: Enhanced boost jump",
                "MOUSE WHEEL: Precision flight control"
            ]),
            ("POWER MATRIX", Colors.QUANTUM_GOLD, [
                "Energy Stars: Restore boost power",
                "Shield Cores: Temporary invulnerability",
                "Magnet Fields: Auto-collect items"
            ]),
            ("SURVIVAL PROTOCOL", Colors.SAKURA_PINK, [
                "Navigate quantum pipe matrices",
                "Collect energy to maintain boost",
                "Use magnetic fields strategically"
            ])
        ]
        
        for section_title, section_color, items in sections:
            # Section header
            section_surface = self.medium_font.render(f"{section_title}", True, section_color)
            screen.blit(section_surface, (panel_rect.x + 60, y_offset))
            y_offset += 40
            
            # Items
            for item in items:
                item_surface = self.small_font.render(f"  -> {item}", True, Colors.CHROME_SILVER)
                screen.blit(item_surface, (panel_rect.x + 80, y_offset))
                y_offset += 30
            y_offset += 20
        
        # Control buttons
        button_width = 180
        button_height = 60
        start_rect = pygame.Rect(panel_rect.centerx - button_width - 20, panel_rect.bottom - 100, button_width, button_height)
        back_rect = pygame.Rect(panel_rect.centerx + 20, panel_rect.bottom - 100, button_width, button_height)
        
        UIElement.draw_hologram_button(screen, start_rect, "BEGIN FLIGHT", self.medium_font, False, Colors.MATRIX_GREEN)
        UIElement.draw_hologram_button(screen, back_rect, "RETURN", self.medium_font, False, Colors.ENERGY_RED)
        
        return start_rect, back_rect
    
    def draw_game_over(self, screen):
        # Game over overlay with enhanced effects
        overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        pygame.draw.rect(overlay, (*Colors.VOID_BLACK, 200), (0, 0, WINDOW_WIDTH, WINDOW_HEIGHT))
        screen.blit(overlay, (0, 0))
        
        panel_width, panel_height = 600, 700
        panel_rect = pygame.Rect(WINDOW_WIDTH // 2 - panel_width // 2, WINDOW_HEIGHT // 2 - panel_height // 2, panel_width, panel_height)
        UIElement.draw_anime_panel(screen, panel_rect, "SYSTEM_FAILURE", Colors.ENERGY_RED)
        
        y_offset = panel_rect.y + 60
        
        # Dramatic title
        title_text = self.title_font.render("MISSION FAILED", True, Colors.ENERGY_RED)
        title_rect = title_text.get_rect(center=(panel_rect.centerx, y_offset))
        screen.blit(title_text, title_rect)
        y_offset += 120
        
        # Stats display with enhanced formatting
        stats_data = [
            ("FINAL SCORE", f"{self.score:04d}", Colors.QUANTUM_GOLD),
            ("FLIGHT TIME", f"{self.stats['flight_time']}s", Colors.ELECTRIC_BLUE),
            ("BOOST USAGE", str(self.stats['boosts_used']), Colors.SAKURA_PINK),
            ("POWER-UPS", str(self.stats['powerups_collected']), Colors.VIOLET_STORM),
            ("BEST STREAK", str(self.stats['best_streak']), Colors.NEON_GREEN),
            ("HIGH SCORE", f"{self.best_score:04d}", Colors.HOLOGRAM_WHITE)
        ]
        
        for label, value, color in stats_data:
            # Stat line with enhanced styling
            label_surface = self.small_font.render(f"{label}:", True, Colors.CHROME_SILVER)
            value_surface = self.medium_font.render(value, True, color)
            
            screen.blit(label_surface, (panel_rect.x + 60, y_offset))
            screen.blit(value_surface, (panel_rect.x + 300, y_offset - 5))
            y_offset += 50
        
        # Action buttons
        button_width = 200
        button_height = 70
        retry_rect = pygame.Rect(panel_rect.centerx - button_width - 20, panel_rect.bottom - 120, button_width, button_height)
        menu_rect = pygame.Rect(panel_rect.centerx + 20, panel_rect.bottom - 120, button_width, button_height)
        
        UIElement.draw_hologram_button(screen, retry_rect, "RETRY MISSION", self.medium_font, False, Colors.MATRIX_GREEN)
        UIElement.draw_hologram_button(screen, menu_rect, "MAIN TERMINAL", self.medium_font, False, Colors.ELECTRIC_BLUE)
        
        return retry_rect, menu_rect
    
    def start_game(self):
        self.state = GameState.PLAYING
        self.reset_game()
        self.start_time = pygame.time.get_ticks()
    
    def reset_game(self):
        self.bird = Bird(250, WINDOW_HEIGHT // 2)
        self.pipes = []
        self.power_ups = []
        self.boost_system = BoostSystem()
        self.particle_system = ParticleSystem()
        self.score = 0
        self.pipe_timer = 0
        
        self.stats['boosts_used'] = 0
        self.stats['current_streak'] = 0
        self.frame_count = 0
    
    def end_game(self):
        self.state = GameState.GAME_OVER
        self.stats['current_streak'] = 0
        self.stats['flight_time'] = (pygame.time.get_ticks() - self.start_time) // 1000
        
        # Enhanced explosion effect
        for _ in range(100):
            self.particle_system.add_particle(self.bird.x, self.bird.y, Colors.ENERGY_RED, "explosion", 1)
        
        self.save_game_data()
    
    def handle_jump(self, use_boost=False):
        if self.state == GameState.PLAYING:
            if use_boost and self.boost_system.use_boost():
                self.bird.jump(True)
                self.stats['boosts_used'] += 1
                self.particle_system.add_particle(self.bird.x, self.bird.y, Colors.SAKURA_PINK, "energy", 30)
                self.show_achievement("QUANTUM BOOST ACTIVATED")
            else:
                self.bird.jump(False)
                self.particle_system.add_particle(self.bird.x - 20, self.bird.y + 20, Colors.NEON_CYAN, "trail", 12)
    
    def update_game(self):
        if self.state == GameState.PLAYING:
            if self.bird.update():
                self.end_game()
            
            self.update_pipes()
            self.update_power_ups()
            self.boost_system.update()
        
        self.update_stars()
        self.particle_system.update()
        self.frame_count += 1
    
    def draw_game(self, screen):
        self.draw_background(screen)
        
        for pipe in self.pipes:
            pipe.draw(screen)
        
        self.draw_power_ups(screen)
        self.particle_system.draw(screen)
        self.bird.draw(screen, self.boost_system.active, self.frame_count)
        self.draw_ground(screen)
        self.draw_hud(screen)
    
    def run(self):
        running = True
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        keys = pygame.key.get_pressed()
                        use_boost = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]
                        
                        if self.state == GameState.MENU:
                            self.start_game()
                        elif self.state == GameState.TUTORIAL:
                            self.state = GameState.MENU
                        elif self.state == GameState.GAME_OVER:
                            self.start_game()
                        else:
                            self.handle_jump(use_boost)
                    
                    elif event.key == pygame.K_ESCAPE:
                        if self.state in [GameState.DIFFICULTY, GameState.TUTORIAL, GameState.PLAYING]:
                            self.state = GameState.MENU
                    
                    elif event.key == pygame.K_1:
                        self.difficulty = Difficulty.EASY
                        if self.state == GameState.DIFFICULTY:
                            self.state = GameState.MENU
                    elif event.key == pygame.K_2:
                        self.difficulty = Difficulty.NORMAL
                        if self.state == GameState.DIFFICULTY:
                            self.state = GameState.MENU
                    elif event.key == pygame.K_3:
                        self.difficulty = Difficulty.HARD
                        if self.state == GameState.DIFFICULTY:
                            self.state = GameState.MENU
                    elif event.key == pygame.K_4:
                        self.difficulty = Difficulty.INSANE
                        if self.state == GameState.DIFFICULTY:
                            self.state = GameState.MENU
                
                elif event.type == pygame.MOUSEWHEEL:
                    if self.state == GameState.PLAYING:
                        self.bird.scroll_control(event.y)
                
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    keys = pygame.key.get_pressed()
                    use_boost = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]
                    
                    if self.state == GameState.MENU:
                        button_rects = self.draw_menu(self.screen)
                        
                        if button_rects[0].collidepoint(mouse_pos):  # Start
                            self.start_game()
                        elif button_rects[1].collidepoint(mouse_pos):  # Difficulty
                            self.state = GameState.DIFFICULTY
                        elif button_rects[2].collidepoint(mouse_pos):  # Tutorial
                            self.state = GameState.TUTORIAL
                        elif button_rects[3].collidepoint(mouse_pos):  # Exit
                            running = False
                    
                    elif self.state == GameState.DIFFICULTY:
                        button_rects = self.draw_difficulty_select(self.screen)
                        
                        for diff in [Difficulty.EASY, Difficulty.NORMAL, Difficulty.HARD, Difficulty.INSANE]:
                            if button_rects[diff].collidepoint(mouse_pos):
                                self.difficulty = diff
                                self.state = GameState.MENU
                                break
                        
                        if button_rects['back'].collidepoint(mouse_pos):
                            self.state = GameState.MENU
                    
                    elif self.state == GameState.TUTORIAL:
                        start_btn, back_btn = self.draw_tutorial(self.screen)
                        if start_btn.collidepoint(mouse_pos):
                            self.start_game()
                        elif back_btn.collidepoint(mouse_pos):
                            self.state = GameState.MENU
                    
                    elif self.state == GameState.PLAYING:
                        self.handle_jump(use_boost)
                    
                    elif self.state == GameState.GAME_OVER:
                        retry_btn, menu_btn = self.draw_game_over(self.screen)
                        if retry_btn.collidepoint(mouse_pos):
                            self.start_game()
                        elif menu_btn.collidepoint(mouse_pos):
                            self.state = GameState.MENU
            
            self.update_game()
            
            if self.state == GameState.MENU:
                self.draw_menu(self.screen)
            elif self.state == GameState.DIFFICULTY:
                self.draw_difficulty_select(self.screen)
            elif self.state == GameState.TUTORIAL:
                self.draw_tutorial(self.screen)
            elif self.state == GameState.PLAYING:
                self.draw_game(self.screen)
            elif self.state == GameState.GAME_OVER:
                self.draw_game(self.screen)
                self.draw_game_over(self.screen)
            
            pygame.display.flip()
            self.clock.tick(FPS)
        
        pygame.quit()

if __name__ == "__main__":
    try:
        print("QUANTUM FLAPPY BIRD - CYBERPUNK EDITION")
        print("=" * 60)
        print("CONTROL MATRIX:")
        print("  SPACE/CLICK: Standard quantum propulsion")
        print("  SHIFT + SPACE/CLICK: Enhanced boost jump")
        print("  MOUSE WHEEL: Precision flight control")
        print("  1-4 KEYS: Quick difficulty selection")
        print("  ESC: Return to main terminal")
        print("=" * 60)
        print("POWER-UP MATRIX:")
        print("  Energy Stars: Restore boost power")
        print("  Shield Cores: Temporary invulnerability")
        print("  Magnet Fields: Auto-collect items")
        print("=" * 60)
        print("Initializing quantum systems...")
        
        game = FlappyBirdGame()
        game.run()
        
    except ImportError as e:
        print("SYSTEM ERROR: Pygame quantum drivers not found!")
        print("Install quantum drivers: pip install pygame")
        print(f"Details: {e}")
    except Exception as e:
        print(f"CRITICAL SYSTEM FAILURE: {e}")
        print("Ensure Python 3.7+ and Pygame are properly installed.")
        import traceback
        traceback.print_exc()