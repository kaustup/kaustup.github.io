@echo off
title Enhanced Flappy Bird Launcher
color 0A

echo.
echo ========================================
echo    🐦 Enhanced Flappy Bird Launcher 🐦
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python is not installed or not in PATH
    echo 📥 Please install Python from https://python.org
    pause
    exit /b 1
)

echo ✅ Python found!

REM Check if Pygame is installed
python -c "import pygame" >nul 2>&1
if errorlevel 1 (
    echo 📦 Pygame not found. Installing...
    pip install pygame
    if errorlevel 1 (
        echo ❌ Failed to install Pygame
        pause
        exit /b 1
    )
    echo ✅ Pygame installed successfully!
) else (
    echo ✅ Pygame is ready!
)

echo.
echo 🚀 Starting Enhanced Flappy Bird...
echo.

REM Run the game
python flappy_bird.py

if errorlevel 1 (
    echo.
    echo ❌ Game crashed or closed with error
    echo 🔧 Check the error messages above
    pause
)

echo.
echo 👋 Thanks for playing!
pause